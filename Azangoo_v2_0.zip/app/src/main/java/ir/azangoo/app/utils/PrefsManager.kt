package ir.azangoo.app.utils

import android.content.Context
import ir.azangoo.app.model.PrayerType

class PrefsManager(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("azangoo_prefs", Context.MODE_PRIVATE)

    var fajrEnabled: Boolean
        get() = prefs.getBoolean("adhan_fajr", true)
        set(value) = prefs.edit().putBoolean("adhan_fajr", value).apply()

    var dhuhrEnabled: Boolean
        get() = prefs.getBoolean("adhan_dhuhr", true)
        set(value) = prefs.edit().putBoolean("adhan_dhuhr", value).apply()

    var maghribEnabled: Boolean
        get() = prefs.getBoolean("adhan_maghrib", true)
        set(value) = prefs.edit().putBoolean("adhan_maghrib", value).apply()

    // Stored in private internal app storage (filesDir/adhans/<selectedAdhanFile>)
    // Empty or "BUILTIN_CHIME" means built-in offline chime
    var selectedAdhanFile: String
        get() = prefs.getString("selected_adhan_file", AdhanStorageManager.BUILTIN_ID) ?: AdhanStorageManager.BUILTIN_ID
        set(value) = prefs.edit().putString("selected_adhan_file", value).apply()

    var selectedAdhanTitle: String
        get() = prefs.getString("selected_adhan_title", "آوای ملایم پیش‌فرض اذانگو") ?: "آوای ملایم پیش‌فرض اذانگو"
        set(value) = prefs.edit().putString("selected_adhan_title", value).apply()

    var hijriOffsetDays: Int
        get() = prefs.getInt("hijri_offset_days", 0)
        set(value) = prefs.edit().putInt("hijri_offset_days", value.coerceIn(-2, 2)).apply()

    var useAlarmStream: Boolean
        get() = prefs.getBoolean("use_alarm_stream", true)
        set(value) = prefs.edit().putBoolean("use_alarm_stream", value).apply()

    var fadeInEnabled: Boolean
        get() = prefs.getBoolean("fade_in_enabled", true)
        set(value) = prefs.edit().putBoolean("fade_in_enabled", value).apply()

    // 20..100
    var adhanVolumePercent: Int
        get() = prefs.getInt("adhan_volume_percent", 85).coerceIn(20, 100)
        set(value) = prefs.edit().putInt("adhan_volume_percent", value.coerceIn(20, 100)).apply()

    // 0 = off, 5, 10, 15 minutes before prayer
    var preAdhanMinutes: Int
        get() = prefs.getInt("pre_adhan_minutes", 0)
        set(value) = prefs.edit().putInt("pre_adhan_minutes", value).apply()

    // 0 = Follow System, 1 = Light, 2 = Dark
    var themeMode: Int
        get() = prefs.getInt("theme_mode", 0)
        set(value) = prefs.edit().putInt("theme_mode", value).apply()

    // Tasbih persistent state
    var tasbihPreset: Int
        get() = prefs.getInt("tasbih_preset", 0)
        set(value) = prefs.edit().putInt("tasbih_preset", value).apply()

    var tasbihCount: Int
        get() = prefs.getInt("tasbih_count", 0)
        set(value) = prefs.edit().putInt("tasbih_count", value).apply()

    var tasbihVibrate: Boolean
        get() = prefs.getBoolean("tasbih_vibrate", true)
        set(value) = prefs.edit().putBoolean("tasbih_vibrate", value).apply()

    fun isPrayerEnabled(type: PrayerType): Boolean = when (type) {
        PrayerType.FAJR -> fajrEnabled
        PrayerType.DHUHR -> dhuhrEnabled
        PrayerType.MAGHRIB -> maghribEnabled
        else -> false
    }

    fun setPrayerEnabled(type: PrayerType, enabled: Boolean) {
        when (type) {
            PrayerType.FAJR -> fajrEnabled = enabled
            PrayerType.DHUHR -> dhuhrEnabled = enabled
            PrayerType.MAGHRIB -> maghribEnabled = enabled
            else -> Unit
        }
    }
}
