package ir.azangoo.app.alarm

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import ir.azangoo.app.AzangooApp
import ir.azangoo.app.R
import ir.azangoo.app.model.PrayerType
import ir.azangoo.app.ui.MainActivity
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.widget.AzangooWidgetProvider

class AdhanAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            AdhanScheduler.ACTION_PLAY_ADHAN -> {
                val prayerKey = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_KEY)
                val prayerTime = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_TIME) ?: ""

                val serviceIntent = Intent(context, AdhanPlaybackService::class.java).apply {
                    action = AdhanPlaybackService.ACTION_START
                    putExtra(AdhanScheduler.EXTRA_PRAYER_KEY, prayerKey)
                    putExtra(AdhanScheduler.EXTRA_PRAYER_TIME, prayerTime)
                }
                ContextCompat.startForegroundService(context, serviceIntent)

                AdhanScheduler.scheduleAll(context)
                AzangooWidgetProvider.updateAllWidgets(context)
            }

            AdhanScheduler.ACTION_PRE_ADHAN -> {
                val prayerType = PrayerType.fromKey(intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_KEY))
                val prayerTime = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_TIME) ?: ""
                val mins = intent.getIntExtra(AdhanScheduler.EXTRA_PRE_MINUTES, 10)
                showPreAdhanNotification(context, prayerType, prayerTime, mins)
            }

            AdhanScheduler.ACTION_REFRESH_WIDGET,
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED -> {
                AdhanScheduler.scheduleAll(context)
                AzangooWidgetProvider.updateAllWidgets(context)
            }
        }
    }

    private fun showPreAdhanNotification(
        context: Context,
        type: PrayerType,
        timeFormatted: String,
        mins: Int
    ) {
        val openIntent = Intent(context, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            context,
            8800 + type.ordinal,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(context, AzangooApp.CHANNEL_PREADHAN_ID)
            .setSmallIcon(R.drawable.ic_mosque)
            .setContentTitle("${PersianCalendarUtils.toPersianDigits(mins)} دقیقه تا ${type.persianName}")
            .setContentText("وقت ${type.persianName} به افق تهران: ساعت ${PersianCalendarUtils.toPersianDigits(timeFormatted)}")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(7800 + type.ordinal, notif)
    }
}
