package ir.azangoo.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import ir.azangoo.app.R
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class QiblaCompassView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var azimuthDegrees: Float = 0f
        set(value) {
            field = value
            invalidate()
        }

    var qiblaBearingDegrees: Float = 218.4f
        set(value) {
            field = value
            invalidate()
        }

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }

    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val qiblaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val arrowPath = Path()

    fun isAlignedWithQibla(): Boolean {
        var diff = (qiblaBearingDegrees - azimuthDegrees) % 360f
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f
        return abs(diff) <= 6f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = min(cx, cy) * 0.86f
        if (radius <= 0f) return

        val aligned = isAlignedWithQibla()
        val primaryColor = ContextCompat.getColor(context, R.color.azangoo_primary)
        val secondaryColor = ContextCompat.getColor(context, R.color.azangoo_text_secondary)
        val textColor = ContextCompat.getColor(context, R.color.azangoo_text_primary)
        val accentColor = ContextCompat.getColor(context, R.color.azangoo_accent)

        // Outer ring
        ringPaint.color = if (aligned) Color.parseColor("#10B981") else primaryColor
        ringPaint.strokeWidth = if (aligned) 10f else 5f
        canvas.drawCircle(cx, cy, radius, ringPaint)

        // Top fixed phone pointer triangle
        arrowPath.reset()
        arrowPath.moveTo(cx, cy - radius - 18f)
        arrowPath.lineTo(cx - 12f, cy - radius + 4f)
        arrowPath.lineTo(cx + 12f, cy - radius + 4f)
        arrowPath.close()
        qiblaPaint.color = if (aligned) Color.parseColor("#10B981") else accentColor
        canvas.drawPath(arrowPath, qiblaPaint)

        // Rotate dial opposite to phone azimuth
        canvas.save()
        canvas.rotate(-azimuthDegrees, cx, cy)

        // Degree ticks
        for (deg in 0 until 360 step 15) {
            val rad = Math.toRadians(deg.toDouble() - 90.0)
            val isMajor = deg % 90 == 0
            val inner = radius * if (isMajor) 0.82f else 0.90f
            tickPaint.color = if (deg == 0) Color.parseColor("#DC2626") else secondaryColor
            tickPaint.strokeWidth = if (isMajor) 5f else 2f
            canvas.drawLine(
                cx + (cos(rad) * inner).toFloat(),
                cy + (sin(rad) * inner).toFloat(),
                cx + (cos(rad) * (radius - 6f)).toFloat(),
                cy + (sin(rad) * (radius - 6f)).toFloat(),
                tickPaint
            )
        }

        // Cardinal labels (ش = شمال، ق = شرق، ج = جنوب، غ = غرب)
        textPaint.textSize = radius * 0.14f
        val labelRadius = radius * 0.68f
        val labels = listOf(
            Triple(0.0, "ش", Color.parseColor("#DC2626")),
            Triple(90.0, "شرق", textColor),
            Triple(180.0, "ج", textColor),
            Triple(270.0, "غرب", textColor)
        )
        for ((deg, lbl, col) in labels) {
            val rad = Math.toRadians(deg - 90.0)
            textPaint.color = col
            val lx = cx + (cos(rad) * labelRadius).toFloat()
            val ly = cy + (sin(rad) * labelRadius).toFloat() + textPaint.textSize * 0.35f
            canvas.drawText(lbl, lx, ly, textPaint)
        }

        // Qibla directional needle on the dial
        canvas.save()
        canvas.rotate(qiblaBearingDegrees, cx, cy)

        // Main Qibla emerald needle
        arrowPath.reset()
        arrowPath.moveTo(cx, cy - radius * 0.80f)
        arrowPath.lineTo(cx - radius * 0.085f, cy)
        arrowPath.lineTo(cx + radius * 0.085f, cy)
        arrowPath.close()
        qiblaPaint.color = if (aligned) Color.parseColor("#10B981") else primaryColor
        canvas.drawPath(arrowPath, qiblaPaint)

        // Tail of needle
        arrowPath.reset()
        arrowPath.moveTo(cx, cy + radius * 0.35f)
        arrowPath.lineTo(cx - radius * 0.055f, cy)
        arrowPath.lineTo(cx + radius * 0.055f, cy)
        arrowPath.close()
        qiblaPaint.color = secondaryColor
        canvas.drawPath(arrowPath, qiblaPaint)

        // Small gold Kaaba diamond at needle tip
        val tipY = cy - radius * 0.86f
        val d = radius * 0.06f
        arrowPath.reset()
        arrowPath.moveTo(cx, tipY - d)
        arrowPath.lineTo(cx + d, tipY)
        arrowPath.lineTo(cx, tipY + d)
        arrowPath.lineTo(cx - d, tipY)
        arrowPath.close()
        qiblaPaint.color = accentColor
        canvas.drawPath(arrowPath, qiblaPaint)

        canvas.restore()
        canvas.restore()

        // Center cap
        centerPaint.color = primaryColor
        canvas.drawCircle(cx, cy, radius * 0.07f, centerPaint)
        centerPaint.color = Color.WHITE
        canvas.drawCircle(cx, cy, radius * 0.03f, centerPaint)
    }
}
