package ir.azangoo.app.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import ir.azangoo.app.databinding.ActivityAdhanWebDownloaderBinding
import ir.azangoo.app.utils.AdhanStorageManager
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrefsManager
import java.util.concurrent.Executors

class AdhanWebDownloaderActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_QUERY = "extra_query"
        const val EXTRA_SUGGESTED_TITLE = "extra_suggested_title"
    }

    private lateinit var binding: ActivityAdhanWebDownloaderBinding
    private lateinit var prefs: PrefsManager
    private val executor = Executors.newSingleThreadExecutor()

    private var suggestedTitle: String = "اذان دانلودی"
    private var detectedAudioUrl: String? = null
    private var isDownloading = false

    private val audioSnifferJs = """
        (function() {
            function isAudio(u) {
                if (!u) return false;
                var l = u.toLowerCase();
                return l.indexOf('.mp3') !== -1 || l.indexOf('.m4a') !== -1 || l.indexOf('.ogg') !== -1 || l.indexOf('.wav') !== -1;
            }
            var found = null;
            var audios = document.querySelectorAll('audio, source');
            for (var i = 0; i < audios.length; i++) {
                var s = audios[i].src || audios[i].getAttribute('src');
                if (s && s.indexOf('http') === 0) { found = s; break; }
            }
            if (!found) {
                var links = document.querySelectorAll('a[href]');
                for (var j = 0; j < links.length; j++) {
                    var h = links[j].href;
                    if (isAudio(h)) { found = h; break; }
                }
            }
            if (found && window.AzangooBridge) {
                window.AzangooBridge.onAudioDetected(found);
            }
        })();
    """.trimIndent()

    inner class AudioSnifferBridge {
        @JavascriptInterface
        fun onAudioDetected(url: String) {
            if (url.startsWith("http")) {
                runOnUiThread {
                    detectedAudioUrl = url
                    binding.bannerDetectedAudio.visibility = View.VISIBLE
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        binding = ActivityAdhanWebDownloaderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsManager(this)

        val query = intent.getStringExtra(EXTRA_QUERY) ?: "دانلود اذان موذن زاده اردبیلی mp3"
        suggestedTitle = intent.getStringExtra(EXTRA_SUGGESTED_TITLE) ?: "اذان دانلودی"
        binding.tvWebTitle.text = "دانلود آنلاین: $suggestedTitle"

        binding.btnWebClose.setOnClickListener { finish() }

        binding.btnDownloadDetected.setOnClickListener {
            val u = detectedAudioUrl
            if (!u.isNullOrBlank()) {
                startInAppDownload(u)
            }
        }

        binding.chipGoogle.setOnClickListener {
            loadSearchUrl("https://www.google.com/search?q=${Uri.encode(query)}")
        }
        binding.chipBing.setOnClickListener {
            loadSearchUrl("https://www.bing.com/search?q=${Uri.encode(query)}")
        }
        binding.chipAviny.setOnClickListener {
            loadSearchUrl("https://www.aviny.com")
        }

        setupWebView()
        loadSearchUrl("https://www.google.com/search?q=${Uri.encode(query)}")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val wv = binding.webView
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = AdhanStorageManager.MOBILE_UA
            mediaPlaybackRequiresUserGesture = false
        }
        wv.addJavascriptInterface(AudioSnifferBridge(), "AzangooBridge")

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                binding.webProgress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                binding.webProgress.progress = newProgress
            }
        }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (looksLikeAudioUrl(url)) {
                    startInAppDownload(url)
                    return true
                }
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                detectedAudioUrl = null
                binding.bannerDetectedAudio.visibility = View.GONE
                view?.evaluateJavascript(audioSnifferJs, null)
            }
        }

        wv.setDownloadListener { url, _, _, mimetype, _ ->
            if (looksLikeAudioUrl(url) || (mimetype != null && mimetype.lowercase().startsWith("audio"))) {
                startInAppDownload(url)
            } else if (url.startsWith("http")) {
                startInAppDownload(url)
            }
        }
    }

    private fun looksLikeAudioUrl(url: String): Boolean {
        val lower = url.lowercase()
        return lower.contains(".mp3") || lower.contains(".m4a") || lower.contains(".ogg") || lower.contains(".wav")
    }

    private fun loadSearchUrl(url: String) {
        detectedAudioUrl = null
        binding.bannerDetectedAudio.visibility = View.GONE
        binding.webView.loadUrl(url)
    }

    private fun startInAppDownload(url: String) {
        if (isDownloading) return
        isDownloading = true
        binding.overlayDownloading.visibility = View.VISIBLE
        binding.tvOverlayDownloadText.text = "در حال دانلود و ذخیره در حافظه داخلی اذانگو..."

        executor.execute {
            val res = AdhanStorageManager.downloadFromUrl(
                context = this,
                rawUrl = url,
                displayTitle = suggestedTitle
            ) { pct ->
                runOnUiThread {
                    binding.tvOverlayDownloadText.text =
                        "در حال دانلود «$suggestedTitle» (${PersianCalendarUtils.toPersianDigits(pct)}٪)"
                }
            }

            runOnUiThread {
                isDownloading = false
                binding.overlayDownloading.visibility = View.GONE
                res.onSuccess { saved ->
                    prefs.selectedAdhanFile = saved.fileName
                    prefs.selectedAdhanTitle = saved.displayTitle
                    Toast.makeText(
                        this,
                        "ذخیره و انتخاب شد: ${saved.displayTitle} (بدون نیاز به دسترسی حافظه)",
                        Toast.LENGTH_LONG
                    ).show()
                    finish()
                }.onFailure { err ->
                    Toast.makeText(
                        this,
                        "دانلود نشد: ${err.message ?: "لینک صوتی مستقیم نبود"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (binding.webView.canGoBack()) {
            binding.webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
        binding.webView.destroy()
    }
}
