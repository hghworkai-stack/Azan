package ir.azangoo.app.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.azangoo.app.R
import ir.azangoo.app.alarm.AdhanPlaybackService
import ir.azangoo.app.databinding.ActivityAdhanLibraryBinding
import ir.azangoo.app.databinding.ItemLocalAdhanBinding
import ir.azangoo.app.databinding.ItemOnlineAdhanBinding
import ir.azangoo.app.model.LocalAdhanItem
import ir.azangoo.app.utils.AdhanStorageManager
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrefsManager
import java.util.concurrent.Executors

class AdhanLibraryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdhanLibraryBinding
    private lateinit var prefs: PrefsManager
    private val executor = Executors.newSingleThreadExecutor()

    private val playbackReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            renderDownloadedList()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        binding = ActivityAdhanLibraryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsManager(this)

        binding.btnBack.setOnClickListener { finish() }

        binding.btnOpenWebDownloader.setOnClickListener {
            openWebDownloader("دانلود اذان موذن زاده اردبیلی mp3", "اذان دلخواه")
        }

        binding.btnDirectLinkDownload.setOnClickListener {
            showDirectLinkDialog()
        }

        renderOnlineCatalog()
        renderIranianCatalog()
        renderDownloadedList()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(AdhanPlaybackService.BROADCAST_STATE_CHANGED)
        ContextCompat.registerReceiver(this, playbackReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        renderDownloadedList()
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(playbackReceiver)
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun renderDownloadedList() {
        val container = binding.containerDownloaded
        container.removeAllViews()
        val items = AdhanStorageManager.listDownloadedAdhans(this)
        val selectedFile = prefs.selectedAdhanFile

        for (item in items) {
            val row = ItemLocalAdhanBinding.inflate(LayoutInflater.from(this), container, false)
            val isSelected = (item.fileName == selectedFile)
            val isCurrentlyPlaying = AdhanPlaybackService.isPlaying &&
                AdhanPlaybackService.currentPlayingFile == item.fileName

            row.tvLocalTitle.text = item.displayTitle
            row.tvLocalMeta.text = if (isSelected) {
                "${item.sizeText} • انتخاب‌شده برای پخش"
            } else {
                item.sizeText
            }
            row.tvLocalMeta.setTextColor(
                ContextCompat.getColor(
                    this,
                    if (isSelected) R.color.azangoo_primary else R.color.azangoo_text_secondary
                )
            )

            row.rbSelected.isChecked = isSelected
            row.rbSelected.setOnClickListener { selectLocalAdhan(item) }
            row.root.setOnClickListener { selectLocalAdhan(item) }

            row.btnPreview.setImageResource(
                if (isCurrentlyPlaying) R.drawable.ic_stop else R.drawable.ic_play
            )
            row.btnPreview.setOnClickListener {
                if (isCurrentlyPlaying) {
                    AdhanPlaybackService.stopPlayback(this)
                } else {
                    AdhanPlaybackService.startPreview(this, item.fileName, item.displayTitle)
                }
            }

            row.btnDelete.visibility = if (item.isBuiltIn) View.GONE else View.VISIBLE
            row.btnDelete.setOnClickListener {
                MaterialAlertDialogBuilder(this)
                    .setTitle("حذف اذان")
                    .setMessage("آیا فایل «${item.displayTitle}» حذف شود؟")
                    .setPositiveButton("حذف") { _, _ ->
                        if (isCurrentlyPlaying) AdhanPlaybackService.stopPlayback(this)
                        AdhanStorageManager.deleteAdhan(this, item.fileName)
                        renderDownloadedList()
                    }
                    .setNegativeButton("انصراف", null)
                    .show()
            }

            container.addView(row.root)
        }
    }

    private fun selectLocalAdhan(item: LocalAdhanItem) {
        prefs.selectedAdhanFile = item.fileName
        prefs.selectedAdhanTitle = item.displayTitle
        renderDownloadedList()
        Toast.makeText(this, "انتخاب شد: ${item.displayTitle}", Toast.LENGTH_SHORT).show()
    }

    private fun renderOnlineCatalog() {
        val container = binding.containerOnlineDirect
        container.removeAllViews()
        for (item in AdhanStorageManager.ONLINE_DIRECT_CATALOG) {
            val row = ItemOnlineAdhanBinding.inflate(LayoutInflater.from(this), container, false)
            row.tvOnlineTitle.text = item.title
            row.tvOnlineSubtitle.text = item.subtitle
            row.btnDownloadAction.text = "دانلود"
            row.btnDownloadAction.setOnClickListener {
                val url = item.directUrl
                if (url != null) {
                    downloadDirectUrl(url, item.title, item.id, item.searchQuery)
                } else {
                    openWebDownloader(item.searchQuery, item.title)
                }
            }
            container.addView(row.root)
        }
    }

    private fun renderIranianCatalog() {
        val container = binding.containerIranianWeb
        container.removeAllViews()
        for (item in AdhanStorageManager.IRANIAN_WEB_CATALOG) {
            val row = ItemOnlineAdhanBinding.inflate(LayoutInflater.from(this), container, false)
            row.tvOnlineTitle.text = item.title
            row.tvOnlineSubtitle.text = item.subtitle
            row.btnDownloadAction.text = "جستجو و دانلود"
            row.btnDownloadAction.setOnClickListener {
                openWebDownloader(item.searchQuery, item.title)
            }
            container.addView(row.root)
        }
    }

    private fun openWebDownloader(query: String, suggestedTitle: String) {
        val intent = Intent(this, AdhanWebDownloaderActivity::class.java).apply {
            putExtra(AdhanWebDownloaderActivity.EXTRA_QUERY, query)
            putExtra(AdhanWebDownloaderActivity.EXTRA_SUGGESTED_TITLE, suggestedTitle)
        }
        startActivity(intent)
    }

    private fun showDirectLinkDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 8)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val etTitle = EditText(this).apply {
            hint = "نام دلخواه (مثلاً: اذان موذن‌زاده)"
        }
        val etUrl = EditText(this).apply {
            hint = "لینک مستقیم فایل صوتی (https://...mp3)"
        }
        layout.addView(etTitle)
        layout.addView(etUrl)

        MaterialAlertDialogBuilder(this)
            .setTitle("دانلود از لینک مستقیم صوتی")
            .setView(layout)
            .setPositiveButton("دانلود و ذخیره") { _, _ ->
                val url = etUrl.text.toString().trim()
                val title = etTitle.text.toString().trim().ifBlank { "اذان دانلودی" }
                if (url.isBlank()) {
                    Toast.makeText(this, "لطفاً لینک را وارد کنید", Toast.LENGTH_SHORT).show()
                } else {
                    downloadDirectUrl(url, title, null, "دانلود اذان mp3")
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun downloadDirectUrl(
        url: String,
        title: String,
        preferredId: String?,
        fallbackSearchQuery: String
    ) {
        binding.downloadProgressCard.visibility = View.VISIBLE
        binding.tvDownloadStatus.text = "در حال دانلود «$title»..."
        binding.progressDownload.isIndeterminate = true

        executor.execute {
            val result = AdhanStorageManager.downloadFromUrl(
                context = this,
                rawUrl = url,
                displayTitle = title,
                preferredId = preferredId
            ) { pct ->
                runOnUiThread {
                    binding.progressDownload.isIndeterminate = false
                    binding.progressDownload.progress = pct
                    binding.tvDownloadStatus.text =
                        "در حال دانلود «$title» (${PersianCalendarUtils.toPersianDigits(pct)}٪)"
                }
            }

            runOnUiThread {
                binding.downloadProgressCard.visibility = View.GONE
                result.onSuccess { savedItem ->
                    prefs.selectedAdhanFile = savedItem.fileName
                    prefs.selectedAdhanTitle = savedItem.displayTitle
                    renderDownloadedList()
                    Toast.makeText(this, "دانلود شد و انتخاب گردید: ${savedItem.displayTitle}", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    MaterialAlertDialogBuilder(this)
                        .setTitle("عدم دسترسی مستقیم به سرور")
                        .setMessage("دانلود مستقیم انجام نشد (${err.message ?: "خطای شبکه"}). می‌خواهید همین اذان را از طریق مرورگر داخلی از سایت‌های ایرانی پیدا و دانلود کنید؟")
                        .setPositiveButton("باز کردن مرورگر دانلود") { _, _ ->
                            openWebDownloader(fallbackSearchQuery, title)
                        }
                        .setNegativeButton("بستن", null)
                        .show()
                }
            }
        }
    }
}
