package ir.azangoo.app.model

data class JalaliDate(
    val year: Int,
    val month: Int,
    val day: Int
)

data class HijriDate(
    val year: Int,
    val month: Int,
    val day: Int
)

data class GregorianDate(
    val year: Int,
    val month: Int,
    val day: Int
)

data class CalendarEvent(
    val title: String,
    val isHoliday: Boolean,
    val type: String
)

enum class PrayerType(
    val key: String,
    val persianName: String,
    val alarmId: Int,
    val preAlarmId: Int
) {
    FAJR("fajr", "اذان صبح", 1001, 1101),
    SUNRISE("sunrise", "طلوع آفتاب", 1002, 1102),
    DHUHR("dhuhr", "اذان ظهر", 1003, 1103),
    SUNSET("sunset", "غروب آفتاب", 1004, 1104),
    MAGHRIB("maghrib", "اذان مغرب", 1005, 1105),
    MIDNIGHT("midnight", "نیمه‌شب شرعی", 1006, 1106);

    companion object {
        fun fromKey(key: String?): PrayerType {
            return entries.firstOrNull { it.key == key } ?: DHUHR
        }
    }
}

data class PrayerTimeItem(
    val type: PrayerType,
    val hour: Int,
    val minute: Int
) {
    val totalMinutes: Int get() = hour * 60 + minute
    fun formattedEnglish(): String = String.format("%02d:%02d", hour, minute)
}

data class DailyPrayerTimes(
    val fajr: PrayerTimeItem,
    val sunrise: PrayerTimeItem,
    val dhuhr: PrayerTimeItem,
    val sunset: PrayerTimeItem,
    val maghrib: PrayerTimeItem,
    val midnight: PrayerTimeItem
) {
    fun allOrdered(): List<PrayerTimeItem> = listOf(fajr, sunrise, dhuhr, sunset, maghrib, midnight)
    fun adhanPrayers(): List<PrayerTimeItem> = listOf(fajr, dhuhr, maghrib)
}

data class OnlineAdhanItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val directUrl: String?, // null means open smart in-app web search downloader
    val searchQuery: String
)

data class LocalAdhanItem(
    val fileName: String, // "BUILTIN_CHIME" for built-in sound
    val displayTitle: String,
    val sizeText: String,
    val isBuiltIn: Boolean = false
)
