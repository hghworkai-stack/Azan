package ir.azangoo.app.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import ir.azangoo.app.R
import ir.azangoo.app.databinding.ItemCalendarDayBinding
import ir.azangoo.app.model.JalaliDate
import ir.azangoo.app.utils.PersianCalendarUtils

data class CalendarDayCell(
    val date: JalaliDate?,
    val hijriDay: Int = 0,
    val isToday: Boolean = false,
    val isSelected: Boolean = false,
    val isHoliday: Boolean = false,
    val hasEvents: Boolean = false
)

class CalendarAdapter(
    private val onDayClick: (JalaliDate) -> Unit
) : RecyclerView.Adapter<CalendarAdapter.DayViewHolder>() {

    private var items: List<CalendarDayCell> = emptyList()

    fun submitList(newItems: List<CalendarDayCell>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DayViewHolder {
        val binding = ItemCalendarDayBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return DayViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DayViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class DayViewHolder(private val binding: ItemCalendarDayBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(cell: CalendarDayCell) {
            val ctx = binding.root.context
            if (cell.date == null) {
                binding.tvDayNumber.text = ""
                binding.tvHijriDay.text = ""
                binding.dayCellContainer.background = null
                binding.eventDot.visibility = View.INVISIBLE
                binding.root.setOnClickListener(null)
                return
            }

            binding.tvDayNumber.text = PersianCalendarUtils.toPersianDigits(cell.date.day)
            binding.tvHijriDay.text = PersianCalendarUtils.toPersianDigits(cell.hijriDay)
            binding.eventDot.visibility = if (cell.hasEvents) View.VISIBLE else View.INVISIBLE

            when {
                cell.isSelected -> {
                    binding.dayCellContainer.setBackgroundResource(R.drawable.bg_day_selected)
                    binding.tvDayNumber.setTextColor(ContextCompat.getColor(ctx, R.color.azangoo_on_primary))
                    binding.tvHijriDay.setTextColor(ContextCompat.getColor(ctx, R.color.azangoo_on_primary))
                }
                cell.isToday -> {
                    binding.dayCellContainer.setBackgroundResource(R.drawable.bg_day_today)
                    val color = if (cell.isHoliday) R.color.azangoo_holiday else R.color.azangoo_primary
                    binding.tvDayNumber.setTextColor(ContextCompat.getColor(ctx, color))
                    binding.tvHijriDay.setTextColor(ContextCompat.getColor(ctx, R.color.azangoo_text_secondary))
                }
                else -> {
                    binding.dayCellContainer.background = null
                    val color = if (cell.isHoliday) R.color.azangoo_holiday else R.color.azangoo_text_primary
                    binding.tvDayNumber.setTextColor(ContextCompat.getColor(ctx, color))
                    binding.tvHijriDay.setTextColor(ContextCompat.getColor(ctx, R.color.azangoo_text_secondary))
                }
            }

            binding.root.setOnClickListener {
                onDayClick(cell.date)
            }
        }
    }
}
