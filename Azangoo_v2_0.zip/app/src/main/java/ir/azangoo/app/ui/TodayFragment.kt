package ir.azangoo.app.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import ir.azangoo.app.R
import ir.azangoo.app.alarm.AdhanScheduler
import ir.azangoo.app.databinding.FragmentTodayBinding
import ir.azangoo.app.model.DailyPrayerTimes
import ir.azangoo.app.model.PrayerType
import ir.azangoo.app.utils.EventsRepository
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrayerTimeCalculator
import ir.azangoo.app.utils.PrefsManager
import java.util.Calendar

class TodayFragment : Fragment() {

    private var _binding: FragmentTodayBinding? = null
    private val binding get() = _binding!!

    private val handler = Handler(Looper.getMainLooper())
    private var todayTimes: DailyPrayerTimes? = null
    private lateinit var prefs: PrefsManager

    private val ticker = object : Runnable {
        override fun run() {
            updateLiveClockAndCountdown()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTodayBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PrefsManager(requireContext())

        setupQuickToggle(binding.btnToggleFajr, PrayerType.FAJR)
        setupQuickToggle(binding.btnToggleDhuhr, PrayerType.DHUHR)
        setupQuickToggle(binding.btnToggleMaghrib, PrayerType.MAGHRIB)

        binding.cardActiveAdhan.setOnClickListener {
            startActivity(Intent(requireContext(), AdhanLibraryActivity::class.java))
        }
    }

    private fun setupQuickToggle(btn: ImageButton, type: PrayerType) {
        btn.setOnClickListener {
            val newState = !prefs.isPrayerEnabled(type)
            prefs.setPrayerEnabled(type, newState)
            AdhanScheduler.scheduleAll(requireContext())
            updateQuickToggleIcons()
            val msg = if (newState) "پخش ${type.persianName} روشن شد" else "پخش ${type.persianName} خاموش شد"
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        bindTodayData()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun bindTodayData() {
        val ctx = requireContext()

        val todayG = PersianCalendarUtils.todayGregorian()
        val todayJ = PersianCalendarUtils.gregorianToJalali(todayG.year, todayG.month, todayG.day)
        val todayH = PersianCalendarUtils.gregorianToHijri(todayG.year, todayG.month, todayG.day, prefs.hijriOffsetDays)

        binding.tvJalaliDate.text = PersianCalendarUtils.formatJalaliFull(todayJ)
        binding.tvHijriDate.text = PersianCalendarUtils.formatHijriFull(todayH)
        binding.tvGregorianDate.text = PersianCalendarUtils.formatGregorianFull(todayG)
        binding.tvCurrentAdhanName.text = prefs.selectedAdhanTitle

        val times = PrayerTimeCalculator.calculateForTehran(todayG)
        todayTimes = times

        binding.tvTimeFajr.text = PersianCalendarUtils.toPersianDigits(times.fajr.formattedEnglish())
        binding.tvTimeSunrise.text = PersianCalendarUtils.toPersianDigits(times.sunrise.formattedEnglish())
        binding.tvTimeDhuhr.text = PersianCalendarUtils.toPersianDigits(times.dhuhr.formattedEnglish())
        binding.tvTimeSunset.text = PersianCalendarUtils.toPersianDigits(times.sunset.formattedEnglish())
        binding.tvTimeMaghrib.text = PersianCalendarUtils.toPersianDigits(times.maghrib.formattedEnglish())
        binding.tvTimeMidnight.text = PersianCalendarUtils.toPersianDigits(times.midnight.formattedEnglish())

        updateQuickToggleIcons()

        val events = EventsRepository.getEventsForDate(ctx, todayJ, todayH)
        if (events.isEmpty()) {
            binding.tvTodayEvents.text = "امروز مناسبت رسمی یا مذهبی خاصی ثبت نشده است."
        } else {
            val sb = StringBuilder()
            events.forEachIndexed { idx, ev ->
                if (idx > 0) sb.appendLine()
                val tag = if (ev.isHoliday) " • تعطیل رسمی" else ""
                sb.append("• ").append(ev.title).append(tag)
            }
            binding.tvTodayEvents.text = sb.toString()
        }

        updateLiveClockAndCountdown()
    }

    private fun updateQuickToggleIcons() {
        val ctx = context ?: return
        val onColor = ContextCompat.getColor(ctx, R.color.azangoo_primary)
        val offColor = ContextCompat.getColor(ctx, R.color.azangoo_text_secondary)

        fun apply(btn: ImageButton, enabled: Boolean) {
            btn.setImageResource(if (enabled) R.drawable.ic_volume_on else R.drawable.ic_volume_off)
            btn.setColorFilter(if (enabled) onColor else offColor)
            btn.alpha = if (enabled) 1f else 0.55f
        }

        apply(binding.btnToggleFajr, prefs.fajrEnabled)
        apply(binding.btnToggleDhuhr, prefs.dhuhrEnabled)
        apply(binding.btnToggleMaghrib, prefs.maghribEnabled)
    }

    private fun updateLiveClockAndCountdown() {
        val times = todayTimes ?: return
        val now = Calendar.getInstance()
        val nowH = now.get(Calendar.HOUR_OF_DAY)
        val nowM = now.get(Calendar.MINUTE)
        val nowS = now.get(Calendar.SECOND)
        val nowSec = nowH * 3600 + nowM * 60 + nowS

        binding.tvLiveClock.text = PersianCalendarUtils.toPersianDigits(String.format("%02d:%02d", nowH, nowM))

        val ordered = times.allOrdered()
        val nextIndex = ordered.indexOfFirst { it.totalMinutes * 60 > nowSec }
        val nextItem = if (nextIndex >= 0) ordered[nextIndex] else times.fajr

        val remainingSec: Int
        val intervalTotalSec: Int
        if (nextIndex >= 0) {
            val targetSec = nextItem.totalMinutes * 60
            remainingSec = targetSec - nowSec
            val prevSec = if (nextIndex > 0) {
                ordered[nextIndex - 1].totalMinutes * 60
            } else {
                times.midnight.totalMinutes * 60 - 24 * 3600
            }
            intervalTotalSec = (targetSec - prevSec).coerceAtLeast(60)
        } else {
            val targetSec = 24 * 3600 + times.fajr.totalMinutes * 60
            remainingSec = targetSec - nowSec
            val prevSec = times.midnight.totalMinutes * 60
            intervalTotalSec = (targetSec - prevSec).coerceAtLeast(60)
        }

        val elapsedSec = (intervalTotalSec - remainingSec).coerceIn(0, intervalTotalSec)
        val progressPct = ((elapsedSec * 100) / intervalTotalSec).coerceIn(0, 100)
        binding.progressNextPrayer.progress = progressPct

        val h = remainingSec / 3600
        val m = (remainingSec % 3600) / 60
        val s = remainingSec % 60
        val countdownStr = PersianCalendarUtils.toPersianDigits(String.format("%02d:%02d:%02d", h, m, s))

        binding.tvNextPrayerLabel.text =
            "تا ${nextItem.type.persianName} (${PersianCalendarUtils.toPersianDigits(nextItem.formattedEnglish())})"
        binding.tvCountdown.text = countdownStr

        highlightRow(nextItem.type)
    }

    private fun highlightRow(nextType: PrayerType) {
        val rows: Map<PrayerType, View> = mapOf(
            PrayerType.FAJR to binding.rowFajr,
            PrayerType.SUNRISE to binding.rowSunrise,
            PrayerType.DHUHR to binding.rowDhuhr,
            PrayerType.SUNSET to binding.rowSunset,
            PrayerType.MAGHRIB to binding.rowMaghrib,
            PrayerType.MIDNIGHT to binding.rowMidnight
        )
        rows.forEach { (type, view) ->
            if (type == nextType) {
                view.setBackgroundResource(R.drawable.bg_next_prayer_row)
            } else {
                view.background = null
            }
        }
    }
}
