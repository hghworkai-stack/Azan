package ir.azangoo.app.ui

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.azangoo.app.R
import ir.azangoo.app.databinding.FragmentToolsBinding
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrayerTimeCalculator
import ir.azangoo.app.utils.PrefsManager
import kotlin.math.roundToInt

class ToolsFragment : Fragment(), SensorEventListener {

    private var _binding: FragmentToolsBinding? = null
    private val binding get() = _binding!!

    private lateinit var prefs: PrefsManager
    private var sensorManager: SensorManager? = null
    private var rotationSensor: Sensor? = null
    private var accelSensor: Sensor? = null
    private var magSensor: Sensor? = null

    private val gravity = FloatArray(3)
    private val geomagnetic = FloatArray(3)
    private var hasGravity = false
    private var hasGeomagnetic = false
    private var smoothedAzimuth = 0f
    private var wasAligned = false

    private val qiblaBearing = PrayerTimeCalculator.qiblaBearingForTehran().toFloat()

    private val tasbihPresets = arrayOf(
        "تسبیحات حضرت زهرا (س)",
        "صلوات (اللهم صل علی محمد و آل محمد)",
        "استغفار (استغفرالله ربی و اتوب الیه)",
        "ذکر آزاد"
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentToolsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PrefsManager(requireContext())

        binding.qiblaCompass.qiblaBearingDegrees = qiblaBearing
        binding.tvQiblaAngleInfo.text =
            "زاویه قبله تهران: ${PersianCalendarUtils.toPersianDigits(qiblaBearing.roundToInt())} درجه (جنوب‌غربی)"

        sensorManager = requireContext().getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        accelSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        magSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

        if (rotationSensor == null && (accelSensor == null || magSensor == null)) {
            binding.tvQiblaStatus.text = "سنسور قطب‌نما در این گوشی در دسترس نیست (زاویه قبله تهران ۲۱۸° جنوب‌غربی است)"
        }

        binding.btnTasbihTap.setOnClickListener {
            onTasbihIncrement()
        }

        binding.btnTasbihReset.setOnClickListener {
            prefs.tasbihCount = 0
            updateTasbihUi()
        }

        binding.btnTasbihPreset.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("انتخاب ذکر")
                .setSingleChoiceItems(tasbihPresets, prefs.tasbihPreset) { dialog, which ->
                    prefs.tasbihPreset = which
                    prefs.tasbihCount = 0
                    updateTasbihUi()
                    dialog.dismiss()
                }
                .show()
        }

        binding.switchTasbihVibrate.isChecked = prefs.tasbihVibrate
        binding.switchTasbihVibrate.setOnCheckedChangeListener { _, isChecked ->
            prefs.tasbihVibrate = isChecked
        }

        updateTasbihUi()
    }

    override fun onResume() {
        super.onResume()
        val sm = sensorManager ?: return
        if (rotationSensor != null) {
            sm.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_UI)
        } else if (accelSensor != null && magSensor != null) {
            sm.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_UI)
            sm.registerListener(this, magSensor, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager?.unregisterListener(this)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onSensorChanged(event: SensorEvent) {
        val rawAzimuth: Float? = when (event.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> {
                val rotMat = FloatArray(9)
                val orientation = FloatArray(3)
                SensorManager.getRotationMatrixFromVector(rotMat, event.values)
                SensorManager.getOrientation(rotMat, orientation)
                ((Math.toDegrees(orientation[0].toDouble()) + 360.0) % 360.0).toFloat()
            }
            Sensor.TYPE_ACCELEROMETER -> {
                System.arraycopy(event.values, 0, gravity, 0, 3)
                hasGravity = true
                computeFallbackAzimuth()
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                System.arraycopy(event.values, 0, geomagnetic, 0, 3)
                hasGeomagnetic = true
                computeFallbackAzimuth()
            }
            else -> null
        }

        if (rawAzimuth != null && _binding != null) {
            var delta = rawAzimuth - smoothedAzimuth
            if (delta > 180f) delta -= 360f
            if (delta < -180f) delta += 360f
            smoothedAzimuth = (smoothedAzimuth + delta * 0.2f + 360f) % 360f

            binding.qiblaCompass.azimuthDegrees = smoothedAzimuth
            val aligned = binding.qiblaCompass.isAlignedWithQibla()
            if (aligned) {
                binding.tvQiblaStatus.text = "در راستای قبله هستید"
                binding.tvQiblaStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.azangoo_primary))
                if (!wasAligned) {
                    vibrateShort(35L)
                }
            } else {
                binding.tvQiblaStatus.text =
                    "گوشی را افقی بگیرید و بچرخانید (جهت فعلی: ${PersianCalendarUtils.toPersianDigits(smoothedAzimuth.roundToInt())}°)"
                binding.tvQiblaStatus.setTextColor(ContextCompat.getColor(requireContext(), R.color.azangoo_text_secondary))
            }
            wasAligned = aligned
        }
    }

    private fun computeFallbackAzimuth(): Float? {
        if (!hasGravity || !hasGeomagnetic) return null
        val r = FloatArray(9)
        val i = FloatArray(9)
        if (!SensorManager.getRotationMatrix(r, i, gravity, geomagnetic)) return null
        val orientation = FloatArray(3)
        SensorManager.getOrientation(r, orientation)
        return ((Math.toDegrees(orientation[0].toDouble()) + 360.0) % 360.0).toFloat()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun onTasbihIncrement() {
        var count = prefs.tasbihCount + 1
        val preset = prefs.tasbihPreset

        if (preset == 0) {
            if (count > 100) count = 1
            if (prefs.tasbihVibrate) {
                val isMilestone = (count == 34 || count == 67 || count == 100)
                vibrateShort(if (isMilestone) 75L else 18L)
            }
        } else {
            if (prefs.tasbihVibrate) {
                vibrateShort(if (count % 100 == 0) 70L else 18L)
            }
        }

        prefs.tasbihCount = count
        updateTasbihUi()
    }

    private fun updateTasbihUi() {
        val preset = prefs.tasbihPreset
        val count = prefs.tasbihCount
        binding.btnTasbihPreset.text = tasbihPresets.getOrElse(preset) { tasbihPresets[0] } + " ▾"

        if (preset == 0) {
            val (stageTitle, stageCount, stageMax) = when {
                count <= 34 -> Triple("الله اکبر", count, 34)
                count <= 67 -> Triple("الحمدلله", count - 34, 33)
                else -> Triple("سبحان الله", count - 67, 33)
            }
            binding.tvTasbihCurrentDhikr.text = stageTitle
            binding.tvTasbihNumber.text = PersianCalendarUtils.toPersianDigits(stageCount)
            binding.tvTasbihSubInfo.text =
                "مرحله: ${PersianCalendarUtils.toPersianDigits(stageCount)} از ${PersianCalendarUtils.toPersianDigits(stageMax)}  •  کل: ${PersianCalendarUtils.toPersianDigits(count)} از ۱۰۰"
        } else {
            binding.tvTasbihCurrentDhikr.text = when (preset) {
                1 -> "اللهم صل علی محمد و آل محمد"
                2 -> "استغفرالله ربی و اتوب الیه"
                else -> "ذکر آزاد"
            }
            binding.tvTasbihNumber.text = PersianCalendarUtils.toPersianDigits(count)
            binding.tvTasbihSubInfo.text = "تعداد کل: ${PersianCalendarUtils.toPersianDigits(count)}"
        }
    }

    private fun vibrateShort(millis: Long) {
        try {
            val ctx = context ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(millis, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(millis, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(millis)
                }
            }
        } catch (_: Exception) {
        }
    }
}
