package ir.azangoo.app.ui

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.azangoo.app.R
import ir.azangoo.app.alarm.AdhanPlaybackService
import ir.azangoo.app.alarm.AdhanScheduler
import ir.azangoo.app.databinding.FragmentSettingsBinding
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrefsManager
import ir.azangoo.app.widget.AzangooWidgetProvider

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    private lateinit var prefs: PrefsManager

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PrefsManager(requireContext())

        binding.btnOpenAdhanLibrary.setOnClickListener {
            startActivity(Intent(requireContext(), AdhanLibraryActivity::class.java))
        }

        binding.btnTestAudio.setOnClickListener {
            val ctx = requireContext()
            if (AdhanPlaybackService.isPlaying) {
                AdhanPlaybackService.stopPlayback(ctx)
            } else {
                AdhanPlaybackService.startPreview(ctx, prefs.selectedAdhanFile, prefs.selectedAdhanTitle)
                Toast.makeText(ctx, "برای قطع پخش، روی اعلان یا دکمه توقف بزنید", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnStopTestAudio.setOnClickListener {
            AdhanPlaybackService.stopPlayback(requireContext())
        }

        binding.switchFajr.isChecked = prefs.fajrEnabled
        binding.switchDhuhr.isChecked = prefs.dhuhrEnabled
        binding.switchMaghrib.isChecked = prefs.maghribEnabled
        binding.switchAlarmStream.isChecked = prefs.useAlarmStream
        binding.switchFadeIn.isChecked = prefs.fadeInEnabled

        binding.switchFajr.setOnCheckedChangeListener { _, isChecked ->
            prefs.fajrEnabled = isChecked
            AdhanScheduler.scheduleAll(requireContext())
        }
        binding.switchDhuhr.setOnCheckedChangeListener { _, isChecked ->
            prefs.dhuhrEnabled = isChecked
            AdhanScheduler.scheduleAll(requireContext())
        }
        binding.switchMaghrib.setOnCheckedChangeListener { _, isChecked ->
            prefs.maghribEnabled = isChecked
            AdhanScheduler.scheduleAll(requireContext())
        }
        binding.switchAlarmStream.setOnCheckedChangeListener { _, isChecked ->
            prefs.useAlarmStream = isChecked
        }
        binding.switchFadeIn.setOnCheckedChangeListener { _, isChecked ->
            prefs.fadeInEnabled = isChecked
        }

        binding.sliderVolume.value = prefs.adhanVolumePercent.toFloat()
        updateVolumeLabel(prefs.adhanVolumePercent)
        binding.sliderVolume.addOnChangeListener { _, value, _ ->
            val pct = value.toInt()
            prefs.adhanVolumePercent = pct
            updateVolumeLabel(pct)
        }

        binding.btnPreAdhanSelector.setOnClickListener {
            val options = arrayOf("خاموش", "۵ دقیقه قبل", "۱۰ دقیقه قبل", "۱۵ دقیقه قبل")
            val values = intArrayOf(0, 5, 10, 15)
            val currentIdx = values.indexOf(prefs.preAdhanMinutes).coerceAtLeast(0)
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("یادآور پیش‌اذان")
                .setSingleChoiceItems(options, currentIdx) { dialog, which ->
                    prefs.preAdhanMinutes = values[which]
                    AdhanScheduler.scheduleAll(requireContext())
                    updatePreAdhanLabel()
                    dialog.dismiss()
                }
                .show()
        }

        binding.btnThemeSelector.setOnClickListener {
            val options = arrayOf("مطابق تم گوشی (خودکار)", "تم روشن", "تم تیره")
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("ظاهر برنامه")
                .setSingleChoiceItems(options, prefs.themeMode) { dialog, which ->
                    prefs.themeMode = which
                    updateThemeLabel()
                    val mode = when (which) {
                        1 -> AppCompatDelegate.MODE_NIGHT_NO
                        2 -> AppCompatDelegate.MODE_NIGHT_YES
                        else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                    }
                    AppCompatDelegate.setDefaultNightMode(mode)
                    dialog.dismiss()
                }
                .show()
        }

        binding.btnHijriMinus.setOnClickListener {
            prefs.hijriOffsetDays = (prefs.hijriOffsetDays - 1).coerceAtLeast(-2)
            updateHijriOffsetUi()
            AzangooWidgetProvider.updateAllWidgets(requireContext())
        }
        binding.btnHijriPlus.setOnClickListener {
            prefs.hijriOffsetDays = (prefs.hijriOffsetDays + 1).coerceAtMost(2)
            updateHijriOffsetUi()
            AzangooWidgetProvider.updateAllWidgets(requireContext())
        }

        binding.btnBatteryOptimization.setOnClickListener { openBatteryOptimizationSettings() }
        binding.btnExactAlarm.setOnClickListener { openExactAlarmSettings() }

        updatePreAdhanLabel()
        updateThemeLabel()
        updateHijriOffsetUi()
    }

    override fun onResume() {
        super.onResume()
        binding.tvSelectedAudio.text = "صدای فعال: ${prefs.selectedAdhanTitle}"
        binding.switchFajr.isChecked = prefs.fajrEnabled
        binding.switchDhuhr.isChecked = prefs.dhuhrEnabled
        binding.switchMaghrib.isChecked = prefs.maghribEnabled
        updatePermissionStatuses()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun updateVolumeLabel(pct: Int) {
        binding.tvVolumeValue.text = "${PersianCalendarUtils.toPersianDigits(pct)}٪"
    }

    private fun updatePreAdhanLabel() {
        val m = prefs.preAdhanMinutes
        binding.btnPreAdhanSelector.text = if (m <= 0) {
            "یادآور پیش‌اذان: خاموش"
        } else {
            "یادآور پیش‌اذان: ${PersianCalendarUtils.toPersianDigits(m)} دقیقه قبل"
        }
    }

    private fun updateThemeLabel() {
        binding.btnThemeSelector.text = when (prefs.themeMode) {
            1 -> "تم برنامه: روشن"
            2 -> "تم برنامه: تیره"
            else -> "تم برنامه: مطابق گوشی (خودکار)"
        }
    }

    private fun updateHijriOffsetUi() {
        val offset = prefs.hijriOffsetDays
        binding.tvHijriOffsetValue.text = when {
            offset > 0 -> "+${PersianCalendarUtils.toPersianDigits(offset)} روز"
            offset < 0 -> "${PersianCalendarUtils.toPersianDigits(offset)} روز"
            else -> "۰ (پیش‌فرض)"
        }
    }

    private fun updatePermissionStatuses() {
        val ctx = requireContext()
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val ignoringBattery = pm.isIgnoringBatteryOptimizations(ctx.packageName)
        binding.tvBatteryStatus.text = if (ignoringBattery) {
            "وضعیت باتری: بدون محدودیت (عالی)"
        } else {
            "وضعیت باتری: محدودیت فعال است (توصیه می‌شود غیرفعال کنید)"
        }
        binding.tvBatteryStatus.setTextColor(
            ContextCompat.getColor(ctx, if (ignoringBattery) R.color.azangoo_primary else R.color.azangoo_holiday)
        )

        val alarmManager = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
        binding.tvExactAlarmStatus.text = if (canExact) "وضعیت آلارم دقیق: فعال" else "وضعیت آلارم دقیق: نیاز به مجوز"
        binding.tvExactAlarmStatus.setTextColor(
            ContextCompat.getColor(ctx, if (canExact) R.color.azangoo_primary else R.color.azangoo_holiday)
        )
    }

    private fun openBatteryOptimizationSettings() {
        val ctx = requireContext()
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${ctx.packageName}")
            }
            startActivity(intent)
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: Exception) {
            }
        }
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:${requireContext().packageName}")
                }
                startActivity(intent)
            } catch (_: Exception) {
            }
        } else {
            Toast.makeText(requireContext(), "آلارم دقیق در این نسخه اندروید خودکار فعال است.", Toast.LENGTH_SHORT).show()
        }
    }
}
