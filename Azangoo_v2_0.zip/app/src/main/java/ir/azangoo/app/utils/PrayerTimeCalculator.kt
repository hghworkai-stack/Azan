package ir.azangoo.app.utils

import ir.azangoo.app.model.DailyPrayerTimes
import ir.azangoo.app.model.GregorianDate
import ir.azangoo.app.model.PrayerTimeItem
import ir.azangoo.app.model.PrayerType
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

object PrayerTimeCalculator {

    const val TEHRAN_LAT = 35.6892
    const val TEHRAN_LNG = 51.3890
    const val IRAN_TZ_OFFSET = 3.5

    private const val KAABA_LAT = 21.422487
    private const val KAABA_LNG = 39.826206

    private fun dsin(d: Double): Double = sin(Math.toRadians(d))
    private fun dcos(d: Double): Double = cos(Math.toRadians(d))
    private fun darcsin(x: Double): Double = Math.toDegrees(asin(x.coerceIn(-1.0, 1.0)))
    private fun darccos(x: Double): Double = Math.toDegrees(acos(x.coerceIn(-1.0, 1.0)))
    private fun darctan2(y: Double, x: Double): Double = Math.toDegrees(atan2(y, x))

    private fun fixAngle(a: Double): Double = a - 360.0 * floor(a / 360.0)
    private fun fixHour(a: Double): Double = a - 24.0 * floor(a / 24.0)

    fun qiblaBearingForTehran(): Double = qiblaBearing(TEHRAN_LAT, TEHRAN_LNG)

    fun qiblaBearing(latDeg: Double, lngDeg: Double): Double {
        val kLat = Math.toRadians(KAABA_LAT)
        val kLng = Math.toRadians(KAABA_LNG)
        val lat = Math.toRadians(latDeg)
        val lng = Math.toRadians(lngDeg)
        val dLng = kLng - lng
        val y = sin(dLng)
        val x = cos(lat) * tan(kLat) - sin(lat) * cos(dLng)
        return fixAngle(Math.toDegrees(atan2(y, x)))
    }

    private fun julianDate(yearInput: Int, monthInput: Int, day: Int): Double {
        var year = yearInput
        var month = monthInput
        if (month <= 2) {
            year -= 1
            month += 12
        }
        val a = floor(year / 100.0)
        val b = 2.0 - a + floor(a / 4.0)
        return floor(365.25 * (year + 4716)) + floor(30.6001 * (month + 1)) + day + b - 1524.5
    }

    private fun sunPosition(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * dsin(g) + 0.020 * dsin(2.0 * g))
        val e = 23.439 - 0.00000036 * d
        val ra = darctan2(dcos(e) * dsin(l), dcos(l)) / 15.0
        val eqt = q / 15.0 - fixHour(ra)
        val decl = darcsin(dsin(e) * dsin(l))
        return Pair(decl, eqt)
    }

    fun calculateForTehran(date: GregorianDate): DailyPrayerTimes {
        return calculate(date.year, date.month, date.day, TEHRAN_LAT, TEHRAN_LNG, IRAN_TZ_OFFSET)
    }

    fun calculate(
        year: Int,
        month: Int,
        day: Int,
        lat: Double,
        lng: Double,
        tz: Double
    ): DailyPrayerTimes {
        val jDate = julianDate(year, month, day) - lng / (15.0 * 24.0)

        fun midDay(t: Double): Double {
            val (_, eqt) = sunPosition(jDate + t)
            return fixHour(12.0 - eqt)
        }

        fun sunAngleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val (decl, _) = sunPosition(jDate + t)
            val noon = midDay(t)
            val cosVal = (-dsin(angle) - dsin(decl) * dsin(lat)) / (dcos(decl) * dcos(lat))
            val delta = (1.0 / 15.0) * darccos(cosVal)
            return if (ccw) noon - delta else noon + delta
        }

        var fajrT = 5.0 / 24.0
        var sunriseT = 6.0 / 24.0
        var dhuhrT = 12.0 / 24.0
        var sunsetT = 18.0 / 24.0
        var maghribT = 18.0 / 24.0

        repeat(2) {
            val f = sunAngleTime(17.7, fajrT, ccw = true)
            val sr = sunAngleTime(0.833, sunriseT, ccw = true)
            val dh = midDay(dhuhrT)
            val ss = sunAngleTime(0.833, sunsetT, ccw = false)
            val mg = sunAngleTime(4.5, maghribT, ccw = false)
            fajrT = f / 24.0
            sunriseT = sr / 24.0
            dhuhrT = dh / 24.0
            sunsetT = ss / 24.0
            maghribT = mg / 24.0
        }

        val adj = tz - lng / 15.0
        val fajrH = fajrT * 24.0 + adj
        val sunriseH = sunriseT * 24.0 + adj
        val dhuhrH = dhuhrT * 24.0 + adj
        val sunsetH = sunsetT * 24.0 + adj
        val maghribH = maghribT * 24.0 + adj
        val midnightH = fixHour(sunsetH + fixHour(fajrH - sunsetH) / 2.0)

        fun toItem(type: PrayerType, hours: Double): PrayerTimeItem {
            val rounded = fixHour(hours + 0.5 / 60.0)
            val h = floor(rounded).toInt()
            val m = floor((rounded - h) * 60.0).toInt()
            return PrayerTimeItem(type, h, m)
        }

        return DailyPrayerTimes(
            fajr = toItem(PrayerType.FAJR, fajrH),
            sunrise = toItem(PrayerType.SUNRISE, sunriseH),
            dhuhr = toItem(PrayerType.DHUHR, dhuhrH),
            sunset = toItem(PrayerType.SUNSET, sunsetH),
            maghrib = toItem(PrayerType.MAGHRIB, maghribH),
            midnight = toItem(PrayerType.MIDNIGHT, midnightH)
        )
    }
}
