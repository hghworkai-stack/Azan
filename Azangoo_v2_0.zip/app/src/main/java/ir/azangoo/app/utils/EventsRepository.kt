package ir.azangoo.app.utils

import android.content.Context
import ir.azangoo.app.model.CalendarEvent
import ir.azangoo.app.model.HijriDate
import ir.azangoo.app.model.JalaliDate
import org.json.JSONObject

object EventsRepository {

    private var loaded = false
    private val shamsiMap = HashMap<Pair<Int, Int>, MutableList<CalendarEvent>>()
    private val hijriMap = HashMap<Pair<Int, Int>, MutableList<CalendarEvent>>()

    @Synchronized
    fun ensureLoaded(context: Context) {
        if (loaded) return
        try {
            val jsonText = context.assets.open("events_iran.json").bufferedReader().use { it.readText() }
            val root = JSONObject(jsonText)

            val shamsiArr = root.optJSONArray("shamsi")
            if (shamsiArr != null) {
                for (i in 0 until shamsiArr.length()) {
                    val obj = shamsiArr.getJSONObject(i)
                    val key = Pair(obj.getInt("month"), obj.getInt("day"))
                    val ev = CalendarEvent(
                        title = obj.getString("title"),
                        isHoliday = obj.optBoolean("isHoliday", false),
                        type = obj.optString("type", "official")
                    )
                    shamsiMap.getOrPut(key) { mutableListOf() }.add(ev)
                }
            }

            val hijriArr = root.optJSONArray("hijri")
            if (hijriArr != null) {
                for (i in 0 until hijriArr.length()) {
                    val obj = hijriArr.getJSONObject(i)
                    val key = Pair(obj.getInt("month"), obj.getInt("day"))
                    val ev = CalendarEvent(
                        title = obj.getString("title"),
                        isHoliday = obj.optBoolean("isHoliday", false),
                        type = obj.optString("type", "religious")
                    )
                    hijriMap.getOrPut(key) { mutableListOf() }.add(ev)
                }
            }
            loaded = true
        } catch (_: Exception) {
        }
    }

    fun getEventsForDate(context: Context, jalali: JalaliDate, hijri: HijriDate): List<CalendarEvent> {
        ensureLoaded(context)
        val result = mutableListOf<CalendarEvent>()
        shamsiMap[Pair(jalali.month, jalali.day)]?.let { result.addAll(it) }
        hijriMap[Pair(hijri.month, hijri.day)]?.let { result.addAll(it) }
        return result
    }

    fun getMonthEvents(
        context: Context,
        year: Int,
        month: Int,
        hijriOffset: Int
    ): List<Pair<Int, CalendarEvent>> {
        ensureLoaded(context)
        val list = mutableListOf<Pair<Int, CalendarEvent>>()
        val days = PersianCalendarUtils.daysInJalaliMonth(year, month)
        for (d in 1..days) {
            val j = JalaliDate(year, month, d)
            val g = PersianCalendarUtils.jalaliToGregorian(year, month, d)
            val h = PersianCalendarUtils.gregorianToHijri(g.year, g.month, g.day, hijriOffset)
            for (ev in getEventsForDate(context, j, h)) {
                list.add(Pair(d, ev))
            }
        }
        return list
    }
}
