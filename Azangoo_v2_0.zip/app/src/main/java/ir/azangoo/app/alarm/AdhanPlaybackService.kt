package ir.azangoo.app.alarm

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import ir.azangoo.app.AzangooApp
import ir.azangoo.app.R
import ir.azangoo.app.model.PrayerType
import ir.azangoo.app.ui.AdhanAlertActivity
import ir.azangoo.app.utils.AdhanStorageManager
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrefsManager

class AdhanPlaybackService : Service() {

    companion object {
        const val ACTION_START = "ir.azangoo.app.SERVICE_START_ADHAN"
        const val ACTION_STOP = "ir.azangoo.app.SERVICE_STOP_ADHAN"
        const val EXTRA_IS_TEST = "extra_is_test"
        const val EXTRA_PREVIEW_FILE = "extra_preview_file"
        const val EXTRA_PREVIEW_TITLE = "extra_preview_title"
        const val BROADCAST_STATE_CHANGED = "ir.azangoo.app.ADHAN_STATE_CHANGED"
        private const val NOTIFICATION_ID = 7701

        @Volatile
        var isPlaying: Boolean = false
            private set

        @Volatile
        var currentTitle: String = ""
            private set

        @Volatile
        var currentPlayingFile: String = ""
            private set

        fun stopPlayback(context: Context) {
            val intent = Intent(context, AdhanPlaybackService::class.java).apply {
                action = ACTION_STOP
            }
            try {
                context.startService(intent)
            } catch (_: Exception) {
            }
        }

        fun startPreview(context: Context, fileName: String, displayTitle: String) {
            val intent = Intent(context, AdhanPlaybackService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_IS_TEST, true)
                putExtra(EXTRA_PREVIEW_FILE, fileName)
                putExtra(EXTRA_PREVIEW_TITLE, displayTitle)
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }

    private var mediaPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val fadeHandler = Handler(Looper.getMainLooper())
    private var fadeRunnable: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAndRelease()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val prayerKey = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_KEY)
                val prayerTime = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_TIME) ?: ""
                val isTest = intent.getBooleanExtra(EXTRA_IS_TEST, false)
                val previewFile = intent.getStringExtra(EXTRA_PREVIEW_FILE)
                val previewTitle = intent.getStringExtra(EXTRA_PREVIEW_TITLE)

                val prayerType = PrayerType.fromKey(prayerKey)
                val title = when {
                    !previewTitle.isNullOrBlank() -> "پخش آزمایشی: $previewTitle"
                    isTest -> "تست پخش اذان"
                    else -> "${prayerType.persianName} به افق تهران"
                }
                startAdhan(title, prayerTime, isTest, previewFile)
            }
        }
        return START_NOT_STICKY
    }

    private fun startAdhan(title: String, timeText: String, isTest: Boolean, overrideFile: String?) {
        releasePlayerOnly()
        acquireWakeLock()

        val prefs = PrefsManager(this)
        val fileKey = overrideFile ?: prefs.selectedAdhanFile

        currentTitle = title
        currentPlayingFile = fileKey
        isPlaying = true
        notifyStateChanged()

        val notification = buildNotification(title, timeText, isTest)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (!isTest) {
            try {
                val alertIntent = Intent(this, AdhanAlertActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("title", title)
                    putExtra("time", timeText)
                }
                startActivity(alertIntent)
            } catch (_: Exception) {
            }
        }

        val audioUsage = if (prefs.useAlarmStream && !isTest) {
            AudioAttributes.USAGE_ALARM
        } else {
            AudioAttributes.USAGE_MEDIA
        }

        val attrs = AudioAttributes.Builder()
            .setUsage(audioUsage)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        val targetVol = (prefs.adhanVolumePercent / 100f).coerceIn(0.2f, 1.0f)
        val useFadeIn = prefs.fadeInEnabled && !isTest

        val localFile = AdhanStorageManager.getAdhanFile(this, fileKey)

        try {
            val mp = MediaPlayer().apply {
                setAudioAttributes(attrs)
                if (localFile != null) {
                    setDataSource(localFile.absolutePath)
                } else {
                    val rawUri = Uri.parse("android.resource://$packageName/${R.raw.adhan_chime}")
                    setDataSource(applicationContext, rawUri)
                }
                setOnCompletionListener {
                    stopAndRelease()
                }
                setOnErrorListener { _, _, _ ->
                    playBuiltinFallback(attrs, targetVol)
                    true
                }
                prepare()
                if (useFadeIn) {
                    setVolume(0.08f, 0.08f)
                } else {
                    setVolume(targetVol, targetVol)
                }
                start()
            }
            mediaPlayer = mp
            if (useFadeIn) {
                startVolumeFadeIn(mp, targetVol)
            }
        } catch (_: Exception) {
            playBuiltinFallback(attrs, targetVol)
        }
    }

    private fun startVolumeFadeIn(mp: MediaPlayer, targetVol: Float) {
        stopFadeIn()
        val steps = 20
        val intervalMs = 450L // ~9 seconds smooth rise
        var currentStep = 1
        val r = object : Runnable {
            override fun run() {
                if (!isPlaying || mediaPlayer !== mp) return
                val frac = currentStep.toFloat() / steps.toFloat()
                val v = (0.08f + (targetVol - 0.08f) * frac).coerceIn(0.08f, targetVol)
                try {
                    mp.setVolume(v, v)
                } catch (_: Exception) {
                    return
                }
                if (currentStep < steps) {
                    currentStep++
                    fadeHandler.postDelayed(this, intervalMs)
                }
            }
        }
        fadeRunnable = r
        fadeHandler.postDelayed(r, intervalMs)
    }

    private fun stopFadeIn() {
        fadeRunnable?.let { fadeHandler.removeCallbacks(it) }
        fadeRunnable = null
    }

    private fun playBuiltinFallback(attrs: AudioAttributes, targetVol: Float) {
        try {
            releasePlayerOnly()
            val rawUri = Uri.parse("android.resource://$packageName/${R.raw.adhan_chime}")
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(attrs)
                setDataSource(applicationContext, rawUri)
                setVolume(targetVol, targetVol)
                setOnCompletionListener { stopAndRelease() }
                prepare()
                start()
            }
        } catch (_: Exception) {
            stopAndRelease()
        }
    }

    private fun buildNotification(title: String, timeText: String, isTest: Boolean): Notification {
        val stopIntent = Intent(this, AdhanPlaybackService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            9001,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alertIntent = Intent(this, AdhanAlertActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("title", title)
            putExtra("time", timeText)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            9002,
            alertIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val subtitle = if (timeText.isNotBlank()) {
            "ساعت ${PersianCalendarUtils.toPersianDigits(timeText)} • برای قطع اذان لمس کنید"
        } else {
            "برای قطع پخش، همین‌جا را لمس کنید"
        }

        val builder = NotificationCompat.Builder(this, AzangooApp.CHANNEL_ADHAN_ID)
            .setSmallIcon(R.drawable.ic_mosque)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(stopPendingIntent)
            .addAction(R.drawable.ic_stop, "قطع اذان", stopPendingIntent)

        if (!isTest) {
            builder.setFullScreenIntent(fullScreenPendingIntent, true)
        }

        return builder.build()
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Azangoo::AdhanWakeLock")
            }
            if (wakeLock?.isHeld == false) {
                wakeLock?.acquire(10 * 60 * 1000L)
            }
        } catch (_: Exception) {
        }
    }

    private fun releasePlayerOnly() {
        stopFadeIn()
        try {
            mediaPlayer?.stop()
        } catch (_: Exception) {
        }
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {
        }
        mediaPlayer = null
    }

    private fun stopAndRelease() {
        releasePlayerOnly()
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        isPlaying = false
        currentTitle = ""
        currentPlayingFile = ""
        notifyStateChanged()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notifyStateChanged() {
        val intent = Intent(BROADCAST_STATE_CHANGED).apply {
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    override fun onDestroy() {
        releasePlayerOnly()
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        isPlaying = false
        currentPlayingFile = ""
        super.onDestroy()
    }
}
