package ir.azangoo.app

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import ir.azangoo.app.utils.PrefsManager

class AzangooApp : Application() {

    companion object {
        const val CHANNEL_ADHAN_ID = "azangoo_adhan_channel"
        const val CHANNEL_PREADHAN_ID = "azangoo_preadhan_channel"
    }

    override fun onCreate() {
        super.onCreate()
        applySavedTheme()
        createNotificationChannels()
    }

    private fun applySavedTheme() {
        val mode = when (PrefsManager(this).themeMode) {
            1 -> AppCompatDelegate.MODE_NIGHT_NO
            2 -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(mode)
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java) ?: return

            val adhanChannel = NotificationChannel(
                CHANNEL_ADHAN_ID,
                "پخش اذان",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "اعلان و کنترل پخش اذان (با لمس قطع می‌شود)"
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(adhanChannel)

            val preChannel = NotificationChannel(
                CHANNEL_PREADHAN_ID,
                "یادآور پیش‌اذان",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "یادآور کوتاه چند دقیقه قبل از وقت اذان"
                enableVibration(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(preChannel)
        }
    }
}
