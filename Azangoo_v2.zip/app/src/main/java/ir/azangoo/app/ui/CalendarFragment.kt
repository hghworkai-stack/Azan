package ir.azangoo.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import ir.azangoo.app.databinding.FragmentCalendarBinding
import ir.azangoo.app.model.JalaliDate
import ir.azangoo.app.utils.EventsRepository
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrayerTimeCalculator
import ir.azangoo.app.utils.PrefsManager
import java.util.Calendar

class CalendarFragment : Fragment() {

    private var _binding: FragmentCalendarBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: CalendarAdapter
    private var currentYear: Int = 1405
    private var currentMonth: Int = 1
    private var selectedDate: JalaliDate = PersianCalendarUtils.todayJalali()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCalendarBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val today = PersianCalendarUtils.todayJalali()
        currentYear = today.year
        currentMonth = today.month
        selectedDate = today

        adapter = CalendarAdapter { clickedDate ->
            selectedDate = clickedDate
            renderMonth()
            renderSelectedDateDetails()
        }

        binding.rvCalendarGrid.layoutManager = GridLayoutManager(requireContext(), 7)
        binding.rvCalendarGrid.adapter = adapter

        binding.btnPrevMonth.setOnClickListener {
            if (currentMonth == 1) {
                currentMonth = 12
                currentYear -= 1
            } else {
                currentMonth -= 1
            }
            renderMonth()
        }

        binding.btnNextMonth.setOnClickListener {
            if (currentMonth == 12) {
                currentMonth = 1
                currentYear += 1
            } else {
                currentMonth += 1
            }
            renderMonth()
        }

        binding.btnJumpToday.setOnClickListener {
            val t = PersianCalendarUtils.todayJalali()
            currentYear = t.year
            currentMonth = t.month
            selectedDate = t
            renderMonth()
            renderSelectedDateDetails()
        }

        renderMonth()
        renderSelectedDateDetails()
    }

    override fun onResume() {
        super.onResume()
        renderMonth()
        renderSelectedDateDetails()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun renderMonth() {
        val ctx = requireContext()
        val hijriOffset = PrefsManager(ctx).hijriOffsetDays
        val today = PersianCalendarUtils.todayJalali()

        val monthName = PersianCalendarUtils.JALALI_MONTHS[(currentMonth - 1).coerceIn(0, 11)]
        binding.tvMonthTitle.text = "$monthName ${PersianCalendarUtils.toPersianDigits(currentYear)}"

        val firstDow = PersianCalendarUtils.dayOfWeekForJalali(currentYear, currentMonth, 1)
        val leadingEmpty = PersianCalendarUtils.persianWeekdayIndex(firstDow)
        val totalDays = PersianCalendarUtils.daysInJalaliMonth(currentYear, currentMonth)

        val cells = mutableListOf<CalendarDayCell>()
        repeat(leadingEmpty) {
            cells.add(CalendarDayCell(date = null))
        }

        for (day in 1..totalDays) {
            val j = JalaliDate(currentYear, currentMonth, day)
            val g = PersianCalendarUtils.jalaliToGregorian(j.year, j.month, j.day)
            val h = PersianCalendarUtils.gregorianToHijri(g.year, g.month, g.day, hijriOffset)
            val dow = PersianCalendarUtils.dayOfWeekForJalali(j.year, j.month, j.day)
            val isFriday = dow == Calendar.FRIDAY
            val events = EventsRepository.getEventsForDate(ctx, j, h)
            val isHoliday = isFriday || events.any { it.isHoliday }

            cells.add(
                CalendarDayCell(
                    date = j,
                    isToday = (j == today),
                    isSelected = (j == selectedDate),
                    isHoliday = isHoliday,
                    hasEvents = events.isNotEmpty()
                )
            )
        }

        adapter.submitList(cells)
    }

    private fun renderSelectedDateDetails() {
        val ctx = requireContext()
        val hijriOffset = PrefsManager(ctx).hijriOffsetDays
        val j = selectedDate
        val g = PersianCalendarUtils.jalaliToGregorian(j.year, j.month, j.day)
        val h = PersianCalendarUtils.gregorianToHijri(g.year, g.month, g.day, hijriOffset)

        binding.tvSelectedJalali.text = PersianCalendarUtils.formatJalaliFull(j)
        binding.tvSelectedSecondary.text =
            "${PersianCalendarUtils.formatHijriFull(h)}  •  ${PersianCalendarUtils.formatGregorianFull(g)}"

        // Occasions for selected date
        val events = EventsRepository.getEventsForDate(ctx, j, h)
        if (events.isEmpty()) {
            binding.tvSelectedEvents.text = "مناسبتی برای این روز ثبت نشده است."
        } else {
            val sb = StringBuilder()
            events.forEachIndexed { idx, ev ->
                if (idx > 0) sb.appendLine()
                val holidayNote = if (ev.isHoliday) " (تعطیل رسمی)" else ""
                sb.append("• ").append(ev.title).append(holidayNote)
            }
            binding.tvSelectedEvents.text = sb.toString()
        }

        // Tehran prayer times for selected date
        val times = PrayerTimeCalculator.calculateForTehran(g)
        binding.tvCalFajr.text = PersianCalendarUtils.toPersianDigits(times.fajr.formattedEnglish())
        binding.tvCalSunrise.text = PersianCalendarUtils.toPersianDigits(times.sunrise.formattedEnglish())
        binding.tvCalDhuhr.text = PersianCalendarUtils.toPersianDigits(times.dhuhr.formattedEnglish())
        binding.tvCalSunset.text = PersianCalendarUtils.toPersianDigits(times.sunset.formattedEnglish())
        binding.tvCalMaghrib.text = PersianCalendarUtils.toPersianDigits(times.maghrib.formattedEnglish())
        binding.tvCalMidnight.text = PersianCalendarUtils.toPersianDigits(times.midnight.formattedEnglish())
    }
}
