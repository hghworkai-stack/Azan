package ir.azangoo.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import ir.azangoo.app.widget.AzangooWidgetProvider

class AdhanAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            AdhanScheduler.ACTION_PLAY_ADHAN -> {
                val prayerKey = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_KEY)
                val prayerTime = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_TIME) ?: ""

                val serviceIntent = Intent(context, AdhanPlaybackService::class.java).apply {
                    action = AdhanPlaybackService.ACTION_START
                    putExtra(AdhanScheduler.EXTRA_PRAYER_KEY, prayerKey)
                    putExtra(AdhanScheduler.EXTRA_PRAYER_TIME, prayerTime)
                }
                ContextCompat.startForegroundService(context, serviceIntent)

                // Immediately reschedule next alarms and refresh widget
                AdhanScheduler.scheduleAll(context)
                AzangooWidgetProvider.updateAllWidgets(context)
            }

            AdhanScheduler.ACTION_REFRESH_WIDGET,
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED -> {
                AdhanScheduler.scheduleAll(context)
                AzangooWidgetProvider.updateAllWidgets(context)
            }
        }
    }
}
