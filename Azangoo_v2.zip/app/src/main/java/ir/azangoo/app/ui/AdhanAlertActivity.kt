package ir.azangoo.app.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import ir.azangoo.app.alarm.AdhanPlaybackService
import ir.azangoo.app.databinding.ActivityAdhanAlertBinding
import ir.azangoo.app.utils.PersianCalendarUtils

class AdhanAlertActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdhanAlertBinding

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (!AdhanPlaybackService.isPlaying) {
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        binding = ActivityAdhanAlertBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val title = intent.getStringExtra("title") ?: AdhanPlaybackService.currentTitle.ifBlank { "وقت اذان" }
        val time = intent.getStringExtra("time") ?: ""

        binding.tvAlertTitle.text = title
        binding.tvAlertTime.text = if (time.isNotBlank()) PersianCalendarUtils.toPersianDigits(time) else ""
        binding.tvAlertTime.visibility = if (time.isNotBlank()) View.VISIBLE else View.GONE

        // Tap ANYWHERE on screen to stop Adhan immediately
        binding.alertRoot.setOnClickListener {
            stopAndClose()
        }
        binding.btnStopAdhan.setOnClickListener {
            stopAndClose()
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(AdhanPlaybackService.BROADCAST_STATE_CHANGED)
        ContextCompat.registerReceiver(this, stateReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        if (!AdhanPlaybackService.isPlaying) {
            finish()
        }
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(stateReceiver)
        } catch (_: Exception) {
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            stopAndClose()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun stopAndClose() {
        AdhanPlaybackService.stopPlayback(this)
        finish()
    }
}
