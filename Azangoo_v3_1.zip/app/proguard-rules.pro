# Keep JavascriptInterface methods in WebView downloader
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface

# Keep Widgets, Receivers, Services
-keep class ir.azangoo.app.widget.** { *; }
-keep class ir.azangoo.app.alarm.** { *; }
