package ir.azangoo.app.utils

import android.content.Context
import ir.azangoo.app.model.JalaliDate
import ir.azangoo.app.model.TodoListModel
import ir.azangoo.app.model.TodoRepeatType
import ir.azangoo.app.model.TodoStep
import ir.azangoo.app.model.TodoTask
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

object TodoRepository {

    const val LIST_MY_DAY = "smart_my_day"
    const val LIST_IMPORTANT = "smart_important"
    const val LIST_PLANNED = "smart_planned"
    const val LIST_ALL = "smart_all"
    const val LIST_DEFAULT = "default_tasks"

    private const val FILE_NAME = "azangoo_todos.json"

    private fun dataFile(context: Context): File = File(context.applicationContext.filesDir, FILE_NAME)

    @Synchronized
    fun loadRawJson(context: Context): JSONObject {
        val f = dataFile(context)
        return try {
            val txt = SecureStorage.readEncryptedText(f); if (txt != null) JSONObject(txt) else createDefaultJson()
        } catch (_: Exception) {
            createDefaultJson()
        }
    }

    @Synchronized
    fun saveRawJson(context: Context, root: JSONObject) {
        try {
            SecureStorage.writeEncryptedText(dataFile(context), root.toString())
        } catch (_: Exception) {
        }
    }

    private fun createDefaultJson(): JSONObject {
        val lists = JSONArray().apply {
            put(JSONObject().apply {
                put("id", LIST_DEFAULT)
                put("name", "کارها")
                put("colorHex", "#0F766E")
            })
        }
        return JSONObject().apply {
            put("lists", lists)
            put("tasks", JSONArray())
        }
    }

    fun getCustomLists(context: Context): List<TodoListModel> {
        val root = loadRawJson(context)
        val arr = root.optJSONArray("lists") ?: return listOf(TodoListModel(LIST_DEFAULT, "کارها"))
        val res = mutableListOf<TodoListModel>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            res.add(
                TodoListModel(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    colorHex = o.optString("colorHex", "#0F766E")
                )
            )
        }
        if (res.none { it.id == LIST_DEFAULT }) {
            res.add(0, TodoListModel(LIST_DEFAULT, "کارها", "#0F766E"))
        }
        return res
    }

    fun addCustomList(context: Context, name: String, colorHex: String = "#0F766E"): TodoListModel {
        val root = loadRawJson(context)
        val arr = root.optJSONArray("lists") ?: JSONArray()
        val item = TodoListModel(id = "list_${UUID.randomUUID().toString().take(8)}", name = name.trim(), colorHex = colorHex)
        arr.put(JSONObject().apply {
            put("id", item.id)
            put("name", item.name)
            put("colorHex", item.colorHex)
        })
        root.put("lists", arr)
        saveRawJson(context, root)
        return item
    }

    fun deleteCustomList(context: Context, listId: String) {
        if (listId == LIST_DEFAULT) return
        val root = loadRawJson(context)
        val arr = root.optJSONArray("lists") ?: JSONArray()
        val newLists = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getString("id") != listId) newLists.put(o)
        }
        root.put("lists", newLists)

        val tasks = getAllTasks(context).filter { it.listId != listId }
        saveTasksInternal(root, tasks)
        saveRawJson(context, root)
    }

    fun getAllTasks(context: Context): List<TodoTask> {
        val root = loadRawJson(context)
        val arr = root.optJSONArray("tasks") ?: return emptyList()
        val list = mutableListOf<TodoTask>()
        for (i in 0 until arr.length()) {
            list.add(parseTask(arr.getJSONObject(i)))
        }
        return list
    }

    fun getTasksForFilter(context: Context, filterId: String): List<TodoTask> {
        val all = getAllTasks(context)
        val todayKey = PersianCalendarUtils.todayDateKey()
        val filtered = when (filterId) {
            LIST_MY_DAY -> all.filter { it.myDayDateKey == todayKey || (!it.isCompleted && it.dueDateKey == todayKey) }
            LIST_IMPORTANT -> all.filter { it.isImportant }
            LIST_PLANNED -> all.filter { !it.dueDateKey.isNullOrBlank() }
            LIST_ALL -> all
            else -> all.filter { it.listId == filterId }
        }
        return filtered.sortedWith(
            compareBy<TodoTask> { it.isCompleted }
                .thenByDescending { it.isImportant }
                .thenBy { it.dueDateKey ?: "9999-99-99" }
                .thenByDescending { it.createdAt }
        )
    }

    fun getTasksForDate(context: Context, dateKey: String): List<TodoTask> {
        return getAllTasks(context).filter { it.dueDateKey == dateKey }
    }

    fun getSuggestedTasksForMyDay(context: Context): List<TodoTask> {
        val todayKey = PersianCalendarUtils.todayDateKey()
        return getAllTasks(context).filter {
            !it.isCompleted && it.myDayDateKey != todayKey && it.dueDateKey != todayKey
        }
    }

    fun upsertTask(context: Context, task: TodoTask) {
        val root = loadRawJson(context)
        val tasks = getAllTasks(context).toMutableList()
        val idx = tasks.indexOfFirst { it.id == task.id }
        if (idx >= 0) tasks[idx] = task else tasks.add(0, task)
        saveTasksInternal(root, tasks)
        saveRawJson(context, root)
    }

    fun deleteTask(context: Context, taskId: String) {
        val root = loadRawJson(context)
        val tasks = getAllTasks(context).filter { it.id != taskId }
        saveTasksInternal(root, tasks)
        saveRawJson(context, root)
    }

    fun toggleTaskCompleted(context: Context, taskId: String): TodoTask? {
        val root = loadRawJson(context)
        val tasks = getAllTasks(context).toMutableList()
        val idx = tasks.indexOfFirst { it.id == taskId }
        if (idx < 0) return null
        val old = tasks[idx]
        val newCompleted = !old.isCompleted
        val updated = old.copy(isCompleted = newCompleted)
        tasks[idx] = updated

        // If completing a repeating task, auto-create next occurrence!
        if (newCompleted && old.repeatType != TodoRepeatType.NONE) {
            val baseDate = PersianCalendarUtils.parseDateKey(old.dueDateKey) ?: PersianCalendarUtils.todayJalali()
            val nextDate: JalaliDate = when (old.repeatType) {
                TodoRepeatType.DAILY -> PersianCalendarUtils.addDaysJalali(baseDate, 1)
                TodoRepeatType.WEEKLY -> PersianCalendarUtils.addDaysJalali(baseDate, 7)
                TodoRepeatType.MONTHLY -> PersianCalendarUtils.addMonthsJalali(baseDate, 1)
                TodoRepeatType.YEARLY -> PersianCalendarUtils.addMonthsJalali(baseDate, 12)
                TodoRepeatType.NONE -> baseDate
            }
            val nextTask = old.copy(
                id = "task_${UUID.randomUUID().toString().take(8)}",
                isCompleted = false,
                dueDateKey = PersianCalendarUtils.toDateKey(nextDate),
                myDayDateKey = null,
                steps = old.steps.map { it.copy(isDone = false) },
                createdAt = System.currentTimeMillis()
            )
            tasks.add(0, nextTask)
        }

        saveTasksInternal(root, tasks)
        saveRawJson(context, root)
        return updated
    }

    fun toggleTaskImportant(context: Context, taskId: String) {
        val root = loadRawJson(context)
        val tasks = getAllTasks(context).toMutableList()
        val idx = tasks.indexOfFirst { it.id == taskId }
        if (idx < 0) return
        tasks[idx] = tasks[idx].copy(isImportant = !tasks[idx].isImportant)
        saveTasksInternal(root, tasks)
        saveRawJson(context, root)
    }

    private fun saveTasksInternal(root: JSONObject, tasks: List<TodoTask>) {
        val arr = JSONArray()
        for (t in tasks) {
            val stepsArr = JSONArray()
            for (s in t.steps) {
                stepsArr.put(JSONObject().apply {
                    put("id", s.id)
                    put("title", s.title)
                    put("isDone", s.isDone)
                })
            }
            arr.put(JSONObject().apply {
                put("id", t.id)
                put("listId", t.listId)
                put("title", t.title)
                put("note", t.note)
                put("isCompleted", t.isCompleted)
                put("isImportant", t.isImportant)
                put("myDayDateKey", t.myDayDateKey ?: JSONObject.NULL)
                put("dueDateKey", t.dueDateKey ?: JSONObject.NULL)
                put("reminderTime", t.reminderTime ?: JSONObject.NULL)
                put("repeatType", t.repeatType.key)
                put("steps", stepsArr)
                put("createdAt", t.createdAt)
            })
        }
        root.put("tasks", arr)
    }

    private fun parseTask(o: JSONObject): TodoTask {
        val stepsList = mutableListOf<TodoStep>()
        val sArr = o.optJSONArray("steps")
        if (sArr != null) {
            for (i in 0 until sArr.length()) {
                val so = sArr.getJSONObject(i)
                stepsList.add(
                    TodoStep(
                        id = so.optString("id", "s_$i"),
                        title = so.optString("title", ""),
                        isDone = so.optBoolean("isDone", false)
                    )
                )
            }
        }
        return TodoTask(
            id = o.getString("id"),
            listId = o.optString("listId", LIST_DEFAULT),
            title = o.getString("title"),
            note = o.optString("note", ""),
            isCompleted = o.optBoolean("isCompleted", false),
            isImportant = o.optBoolean("isImportant", false),
            myDayDateKey = if (o.isNull("myDayDateKey")) null else o.optString("myDayDateKey", null),
            dueDateKey = if (o.isNull("dueDateKey")) null else o.optString("dueDateKey", null),
            reminderTime = if (o.isNull("reminderTime")) null else o.optString("reminderTime", null),
            repeatType = TodoRepeatType.fromKey(o.optString("repeatType", "none")),
            steps = stepsList,
            createdAt = o.optLong("createdAt", System.currentTimeMillis())
        )
    }
}
