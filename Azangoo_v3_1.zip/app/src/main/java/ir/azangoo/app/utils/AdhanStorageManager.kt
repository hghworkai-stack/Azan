package ir.azangoo.app.utils

import android.content.Context
import ir.azangoo.app.model.LocalAdhanItem
import ir.azangoo.app.model.OnlineAdhanItem
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

object AdhanStorageManager {

    const val BUILTIN_ID = "BUILTIN_CHIME"
    private const val DIR_NAME = "adhans"
    private const val META_FILE = "adhans_meta.json"
    const val MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 13; SM-A505F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    val ONLINE_DIRECT_CATALOG: List<OnlineAdhanItem> = listOf(
        OnlineAdhanItem(
            id = "makkah",
            title = "اذان مسجدالحرام (مکه مکرمه)",
            subtitle = "دانلود مستقیم آنلاین • کیفیت شفاف",
            directUrl = "https://www.islamcan.com/audio/adhan/azan1.mp3",
            searchQuery = "دانلود اذان مکه مسجدالحرام mp3"
        ),
        OnlineAdhanItem(
            id = "madinah",
            title = "اذان مسجدالنبی (مدینه منوره)",
            subtitle = "دانلود مستقیم آنلاین • آرام و دلنشین",
            directUrl = "https://www.islamcan.com/audio/adhan/azan2.mp3",
            searchQuery = "دانلود اذان مدینه مسجدالنبی mp3"
        ),
        OnlineAdhanItem(
            id = "aqsa",
            title = "اذان مسجدالاقصی",
            subtitle = "دانلود مستقیم آنلاین",
            directUrl = "https://www.islamcan.com/audio/adhan/azan3.mp3",
            searchQuery = "دانلود اذان مسجدالاقصی mp3"
        ),
        OnlineAdhanItem(
            id = "egypt",
            title = "اذان قاهره (مصر)",
            subtitle = "دانلود مستقیم آنلاین",
            directUrl = "https://www.islamcan.com/audio/adhan/azan4.mp3",
            searchQuery = "دانلود اذان مصر mp3"
        ),
        OnlineAdhanItem(
            id = "alafasy",
            title = "اذان شیخ مشاری العفاسی",
            subtitle = "دانلود مستقیم آنلاین",
            directUrl = "https://www.islamcan.com/audio/adhan/azan15.mp3",
            searchQuery = "دانلود اذان مشاری العفاسی mp3"
        ),
        OnlineAdhanItem(
            id = "abdulbasit",
            title = "اذان استاد عبدالباسط",
            subtitle = "دانلود مستقیم آنلاین",
            directUrl = "https://www.islamcan.com/audio/adhan/azan20.mp3",
            searchQuery = "دانلود اذان عبدالباسط mp3"
        )
    )

    val IRANIAN_WEB_CATALOG: List<OnlineAdhanItem> = listOf(
        OnlineAdhanItem(
            id = "moazzenzadeh",
            title = "مرحوم رحیم مؤذن‌زاده اردبیلی",
            subtitle = "جستجو و دانلود خودکار از سایت‌های ایرانی (بیات ترک)",
            directUrl = null,
            searchQuery = "دانلود اذان رحیم موذن زاده اردبیلی mp3"
        ),
        OnlineAdhanItem(
            id = "aghati",
            title = "حاج محمد آقاتی",
            subtitle = "جستجو و دانلود خودکار از سایت‌های ایرانی",
            directUrl = null,
            searchQuery = "دانلود اذان محمد آقاتی mp3"
        ),
        OnlineAdhanItem(
            id = "rahimi",
            title = "استاد رحیمی",
            subtitle = "جستجو و دانلود خودکار از سایت‌های ایرانی",
            directUrl = null,
            searchQuery = "دانلود اذان رحیمی mp3"
        ),
        OnlineAdhanItem(
            id = "mansouri",
            title = "استاد کریم منصوری",
            subtitle = "جستجو و دانلود خودکار از سایت‌های ایرانی",
            directUrl = null,
            searchQuery = "دانلود اذان کریم منصوری mp3"
        ),
        OnlineAdhanItem(
            id = "ghalwash",
            title = "استاد راغب مصطفی غلوش",
            subtitle = "جستجو و دانلود خودکار از سایت‌های ایرانی",
            directUrl = null,
            searchQuery = "دانلود اذان غلوش mp3"
        )
    )

    fun getAdhanDir(context: Context): File {
        val dir = File(context.applicationContext.filesDir, DIR_NAME)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getAdhanFile(context: Context, fileName: String): File? {
        if (fileName.isBlank() || fileName == BUILTIN_ID) return null
        val f = File(getAdhanDir(context), fileName)
        return if (f.exists() && f.length() > 1024L) f else null
    }

    private fun readMeta(context: Context): JSONObject {
        val metaFile = File(getAdhanDir(context), META_FILE)
        return try {
            if (metaFile.exists()) JSONObject(metaFile.readText(Charsets.UTF_8)) else JSONObject()
        } catch (_: Exception) {
            JSONObject()
        }
    }

    private fun writeMeta(context: Context, json: JSONObject) {
        try {
            val metaFile = File(getAdhanDir(context), META_FILE)
            metaFile.writeText(json.toString(), Charsets.UTF_8)
        } catch (_: Exception) {
        }
    }

    fun saveTitleForFile(context: Context, fileName: String, displayTitle: String) {
        val meta = readMeta(context)
        meta.put(fileName, displayTitle)
        writeMeta(context, meta)
    }

    fun listDownloadedAdhans(context: Context): List<LocalAdhanItem> {
        val result = mutableListOf<LocalAdhanItem>()
        result.add(
            LocalAdhanItem(
                fileName = BUILTIN_ID,
                displayTitle = "آوای ملایم پیش‌فرض اذانگو (آفلاین)",
                sizeText = "داخلی",
                isBuiltIn = true
            )
        )

        val dir = getAdhanDir(context)
        val meta = readMeta(context)
        val files = dir.listFiles()
            ?.filter { it.isFile && it.name != META_FILE && it.length() > 1024L }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

        for (file in files) {
            val title = meta.optString(file.name, file.nameWithoutExtension)
            val kb = file.length() / 1024.0
            val sizeStr = if (kb >= 1024.0) {
                PersianCalendarUtils.toPersianDigits(String.format("%.1f مگابایت", kb / 1024.0))
            } else {
                PersianCalendarUtils.toPersianDigits(String.format("%.0f کیلوبایت", kb))
            }
            result.add(
                LocalAdhanItem(
                    fileName = file.name,
                    displayTitle = title,
                    sizeText = sizeStr,
                    isBuiltIn = false
                )
            )
        }
        return result
    }

    fun deleteAdhan(context: Context, fileName: String) {
        if (fileName == BUILTIN_ID) return
        val f = File(getAdhanDir(context), fileName)
        if (f.exists()) f.delete()
        val meta = readMeta(context)
        meta.remove(fileName)
        writeMeta(context, meta)

        val prefs = PrefsManager(context)
        if (prefs.selectedAdhanFile == fileName) {
            prefs.selectedAdhanFile = BUILTIN_ID
            prefs.selectedAdhanTitle = "آوای ملایم پیش‌فرض اذانگو (آفلاین)"
        }
    }

    /**
     * Downloads an audio file directly into private app internal storage (ZERO storage permissions).
     * Follows redirects across http/https and validates that the response is actually audio, not an HTML error page.
     */
    fun downloadFromUrl(
        context: Context,
        rawUrl: String,
        displayTitle: String,
        preferredId: String? = null,
        onProgress: (Int) -> Unit = {}
    ): Result<LocalAdhanItem> {
        var currentUrl = rawUrl.trim()
        if (!currentUrl.startsWith("https://")) {
            return Result.failure(IllegalArgumentException("برای امنیت بیشتر، فقط لینک‌های امن https:// مجاز هستند"))
        }

        var conn: HttpURLConnection? = null
        try {
            var redirects = 0
            while (redirects < 6) {
                conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 15_000
                    readTimeout = 25_000
                    setRequestProperty("User-Agent", MOBILE_UA)
                    setRequestProperty("Accept", "audio/*, application/octet-stream, */*")
                }
                val code = conn.responseCode
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location")
                    conn.disconnect()
                    if (loc.isNullOrBlank()) break
                    currentUrl = URL(URL(currentUrl), loc).toString()
                    redirects++
                } else {
                    break
                }
            }

            val finalConn = conn ?: return Result.failure(Exception("خطا در برقراری ارتباط با سرور"))
            val code = finalConn.responseCode
            if (code !in 200..299) {
                return Result.failure(Exception("سرور پاسخ نداد (کد خطا: $code)"))
            }

            val contentType = (finalConn.contentType ?: "").lowercase()
            if (contentType.contains("text/html") || contentType.contains("text/plain")) {
                return Result.failure(Exception("این لینک صفحه وب است نه فایل صوتی MP3"))
            }

            val ext = when {
                currentUrl.lowercase().contains(".m4a") || contentType.contains("mp4") -> "m4a"
                currentUrl.lowercase().contains(".ogg") || contentType.contains("ogg") -> "ogg"
                currentUrl.lowercase().contains(".wav") || contentType.contains("wav") -> "wav"
                else -> "mp3"
            }

            val safePrefix = (preferredId ?: "adhan_${System.currentTimeMillis()}")
                .replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val fileName = "$safePrefix.$ext"
            val outFile = File(getAdhanDir(context), fileName)
            val tmpFile = File(getAdhanDir(context), "$fileName.tmp")

            val totalBytes = finalConn.contentLengthLong
            var downloaded = 0L

            finalConn.inputStream.use { input ->
                FileOutputStream(tmpFile).use { output ->
                    val buffer = ByteArray(16 * 1024)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        output.write(buffer, 0, read)
                        downloaded += read
                        if (totalBytes > 0) {
                            val pct = ((downloaded * 100) / totalBytes).toInt().coerceIn(0, 100)
                            onProgress(pct)
                        }
                    }
                }
            }

            if (downloaded < 8 * 1024L) {
                tmpFile.delete()
                return Result.failure(Exception("فایل دریافت‌شده ناقص یا خالی است"))
            }

            // Quick header sanity check: reject accidental HTML payload
            val headBytes = tmpFile.inputStream().use {
                val b = ByteArray(64)
                val n = it.read(b)
                if (n > 0) String(b, 0, n, Charsets.UTF_8).lowercase() else ""
            }
            if (headBytes.contains("<!doctype") || headBytes.contains("<html")) {
                tmpFile.delete()
                return Result.failure(Exception("فایل دریافتی صفحه وب بود نه فایل صوتی"))
            }

            if (outFile.exists()) outFile.delete()
            tmpFile.renameTo(outFile)
            saveTitleForFile(context, fileName, displayTitle)

            val kb = downloaded / 1024.0
            val sizeStr = if (kb >= 1024.0) {
                PersianCalendarUtils.toPersianDigits(String.format("%.1f مگابایت", kb / 1024.0))
            } else {
                PersianCalendarUtils.toPersianDigits(String.format("%.0f کیلوبایت", kb))
            }

            return Result.success(
                LocalAdhanItem(
                    fileName = fileName,
                    displayTitle = displayTitle,
                    sizeText = sizeStr,
                    isBuiltIn = false
                )
            )
        } catch (e: Exception) {
            return Result.failure(e)
        } finally {
            conn?.disconnect()
        }
    }
}
