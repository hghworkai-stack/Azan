package ir.azangoo.app.ui

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import ir.azangoo.app.R
import ir.azangoo.app.alarm.AdhanPlaybackService
import ir.azangoo.app.alarm.AdhanScheduler
import ir.azangoo.app.databinding.ActivityMainBinding
import ir.azangoo.app.utils.PrefsManager
import ir.azangoo.app.widget.AzangooWidgetProvider
import ir.azangoo.app.widget.TodoWidgetProvider

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_OPEN_TAB = "extra_open_tab"
        const val EXTRA_TODO_LIST_ID = "extra_todo_list_id"
        const val EXTRA_QUICK_ADD_TODO = "extra_quick_add_todo"
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsManager
    private var appUnlockedInSession = false
    private var financeUnlockedInSession = false

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val adhanStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            updatePlayingBanner()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        prefs = PrefsManager(this)
        applyFlagSecure()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        requestNotificationPermissionIfNeeded()

        AdhanScheduler.scheduleAll(this)
        AzangooWidgetProvider.updateAllWidgets(this)
        TodoWidgetProvider.updateAllWidgets(this)

        binding.bannerStopAdhan.setOnClickListener {
            AdhanPlaybackService.stopPlayback(this)
            updatePlayingBanner()
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_today -> { showFragment(TodayFragment()); true }
                R.id.nav_calendar -> { showFragment(CalendarFragment()); true }
                R.id.nav_todo -> { showFragment(TodoFragment()); true }
                R.id.nav_finance -> {
                    if (prefs.biometricLockMode >= 1 && !financeUnlockedInSession && !appUnlockedInSession) {
                        authenticateUser(
                            title = "ورود به بخش مالی اذانگو",
                            subtitle = "برای مشاهده اقساط و چک‌ها هویت خود را تأیید کنید",
                            onSuccess = {
                                financeUnlockedInSession = true
                                showFragment(FinanceFragment())
                            },
                            onFail = {
                                Toast.makeText(this, "تأیید هویت انجام نشد", Toast.LENGTH_SHORT).show()
                                binding.bottomNav.selectedItemId = R.id.nav_today
                            }
                        )
                        false
                    } else {
                        showFragment(FinanceFragment())
                        true
                    }
                }
                R.id.nav_settings -> { showFragment(SettingsFragment()); true }
                else -> false
            }
        }

        if (prefs.biometricLockMode == 2 && !appUnlockedInSession) {
            binding.fragmentContainer.visibility = View.INVISIBLE
            authenticateUser(
                title = "ورود امن به اذانگو",
                subtitle = "اثر انگشت یا رمز گوشی را وارد کنید",
                onSuccess = {
                    appUnlockedInSession = true
                    financeUnlockedInSession = true
                    binding.fragmentContainer.visibility = View.VISIBLE
                    if (savedInstanceState == null) handleLaunchIntent(intent)
                },
                onFail = {
                    Toast.makeText(this, "ورود لغو شد", Toast.LENGTH_SHORT).show()
                    finish()
                }
            )
        } else if (savedInstanceState == null) {
            handleLaunchIntent(intent)
        }
    }

    fun applyFlagSecure() {
        if (prefs.flagSecureEnabled) {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    private fun authenticateUser(
        title: String,
        subtitle: String,
        onSuccess: () -> Unit,
        onFail: () -> Unit
    ) {
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.BIOMETRIC_WEAK or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL

        val bm = BiometricManager.from(this)
        if (bm.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            // Device has no lock screen / biometric configured
            onSuccess()
            return
        }

        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                onFail()
            }
        })

        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(authenticators)
            .build()

        prompt.authenticate(info)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleLaunchIntent(intent)
    }

    private fun handleLaunchIntent(intent: Intent?) {
        val openTab = intent?.getIntExtra(EXTRA_OPEN_TAB, R.id.nav_today) ?: R.id.nav_today
        if (openTab == R.id.nav_todo) {
            val listId = intent?.getStringExtra(EXTRA_TODO_LIST_ID)
            val quickAdd = intent?.getBooleanExtra(EXTRA_QUICK_ADD_TODO, false) ?: false
            binding.bottomNav.selectedItemId = R.id.nav_todo
            if (listId != null || quickAdd) {
                showFragment(TodoFragment.newInstance(listId, quickAdd))
            }
        } else {
            binding.bottomNav.selectedItemId = openTab
        }
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(AdhanPlaybackService.BROADCAST_STATE_CHANGED)
        ContextCompat.registerReceiver(this, adhanStateReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        updatePlayingBanner()
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(adhanStateReceiver)
        } catch (_: Exception) {
        }
    }

    private fun updatePlayingBanner() {
        if (AdhanPlaybackService.isPlaying) {
            binding.bannerStopAdhan.visibility = View.VISIBLE
            val title = AdhanPlaybackService.currentTitle.ifBlank { "اذان" }
            binding.tvBannerStopText.text = "$title — برای قطع لمس کنید"
        } else {
            binding.bannerStopAdhan.visibility = View.GONE
        }
    }

    private fun showFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
