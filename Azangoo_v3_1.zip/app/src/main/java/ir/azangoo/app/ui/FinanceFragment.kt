package ir.azangoo.app.ui

import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.azangoo.app.R
import ir.azangoo.app.alarm.AdhanScheduler
import ir.azangoo.app.databinding.FragmentFinanceBinding
import ir.azangoo.app.databinding.ItemDebtCardBinding
import ir.azangoo.app.model.DebtItem
import ir.azangoo.app.model.DebtType
import ir.azangoo.app.model.JalaliDate
import ir.azangoo.app.utils.EventsRepository
import ir.azangoo.app.utils.FinanceRepository
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrefsManager
import java.util.Calendar

class FinanceFragment : Fragment() {

    private var _binding: FragmentFinanceBinding? = null
    private val binding get() = _binding!!

    private lateinit var prefs: PrefsManager
    // 0 = All open, 1 = Installments, 2 = Cheques, 3 = Paid
    private var activeFilter = 0

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFinanceBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PrefsManager(requireContext())

        binding.btnTogglePrivacy.setOnClickListener {
            prefs.hideFinanceAmounts = !prefs.hideFinanceAmounts
            renderAll()
        }

        binding.chipFinAll.setOnClickListener { activeFilter = 0; renderAll() }
        binding.chipFinInstallment.setOnClickListener { activeFilter = 1; renderAll() }
        binding.chipFinCheque.setOnClickListener { activeFilter = 2; renderAll() }
        binding.chipFinPaid.setOnClickListener { activeFilter = 3; renderAll() }

        binding.fabAddDebt.setOnClickListener { showAddDebtDialog() }

        renderAll()
    }

    override fun onResume() {
        super.onResume()
        renderAll()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun formatAmountRespectingPrivacy(amount: Long): String {
        return if (prefs.hideFinanceAmounts) "•••••• تومان" else PersianCalendarUtils.formatToman(amount)
    }

    private fun renderAll() {
        val ctx = requireContext()
        val all = FinanceRepository.getAllItems(ctx)
        val open = all.filter { !it.isPaid }
        val today = PersianCalendarUtils.todayJalali()

        // Privacy icon
        binding.btnTogglePrivacy.setImageResource(
            if (prefs.hideFinanceAmounts) R.drawable.ic_eye_off else R.drawable.ic_eye_on
        )

        // Dashboard metrics
        val thisMonthOpen = open.filter { it.dueYear == today.year && it.dueMonth == today.month }
        val monthSum = thisMonthOpen.sumOf { it.amountToman }
        val totalSum = open.sumOf { it.amountToman }

        binding.tvFinMonthTotal.text = formatAmountRespectingPrivacy(monthSum)
        binding.tvFinAllTotal.text = formatAmountRespectingPrivacy(totalSum)

        val nearest = open.minByOrNull { it.dueDateKey }
        if (nearest == null) {
            binding.tvFinNearestDue.text = "هیچ قسط یا چک پرداخت‌نشده‌ای ثبت نشده است"
        } else {
            val due = JalaliDate(nearest.dueYear, nearest.dueMonth, nearest.dueDay)
            val diff = PersianCalendarUtils.daysBetweenJalali(today, due)
            val diffText = when {
                diff < 0 -> "${PersianCalendarUtils.toPersianDigits(-diff)} روز گذشته!"
                diff == 0 -> "امروز سررسید است!"
                else -> "${PersianCalendarUtils.toPersianDigits(diff)} روز مانده"
            }
            binding.tvFinNearestDue.text = "نزدیک‌ترین سررسید: ${nearest.type.persianName} «${nearest.title}» ($diffText)"
        }

        // Filter list
        val filtered = when (activeFilter) {
            1 -> open.filter { it.type == DebtType.INSTALLMENT }
            2 -> open.filter { it.type == DebtType.CHEQUE }
            3 -> all.filter { it.isPaid }
            else -> open
        }

        binding.containerDebts.removeAllViews()
        if (filtered.isEmpty()) {
            binding.tvFinEmpty.visibility = View.VISIBLE
        } else {
            binding.tvFinEmpty.visibility = View.GONE
            for (item in filtered) {
                binding.containerDebts.addView(buildDebtCard(item, today))
            }
        }
    }

    private fun buildDebtCard(item: DebtItem, today: JalaliDate): View {
        val ctx = requireContext()
        val card = ItemDebtCardBinding.inflate(LayoutInflater.from(ctx), binding.containerDebts, false)
        val due = JalaliDate(item.dueYear, item.dueMonth, item.dueDay)
        val diff = PersianCalendarUtils.daysBetweenJalali(today, due)

        val seriesLabel = if (item.installmentTotal > 1) {
            " (${PersianCalendarUtils.toPersianDigits(item.installmentIndex)} از ${PersianCalendarUtils.toPersianDigits(item.installmentTotal)})"
        } else ""

        card.tvDebtTitle.text = "${item.title}$seriesLabel"
        card.tvDebtAmount.text = formatAmountRespectingPrivacy(item.amountToman)
        card.tvDebtTypeBadge.text = item.type.persianName

        val badgeColor = if (item.type == DebtType.CHEQUE) R.color.azangoo_holiday else R.color.azangoo_primary
        card.tvDebtTypeBadge.setTextColor(ContextCompat.getColor(ctx, badgeColor))

        val countdownStr = when {
            item.isPaid -> "پرداخت‌شده"
            diff < 0 -> "${PersianCalendarUtils.toPersianDigits(-diff)} روز تأخیر"
            diff == 0 -> "امروز سررسید"
            else -> "${PersianCalendarUtils.toPersianDigits(diff)} روز مانده"
        }
        card.tvDebtDueDate.text = "${PersianCalendarUtils.formatJalaliShort(due)} • $countdownStr"
        card.tvDebtDueDate.setTextColor(
            ContextCompat.getColor(
                ctx,
                if (!item.isPaid && diff <= 0) R.color.azangoo_holiday else R.color.azangoo_text_secondary
            )
        )

        // Check holiday clash for Cheques!
        val g = PersianCalendarUtils.jalaliToGregorian(due.year, due.month, due.day)
        val h = PersianCalendarUtils.gregorianToHijri(g.year, g.month, g.day, prefs.hijriOffsetDays)
        val isFriday = PersianCalendarUtils.dayOfWeekForJalali(due.year, due.month, due.day) == Calendar.FRIDAY
        val isHoliday = isFriday || EventsRepository.getEventsForDate(ctx, due, h).any { it.isHoliday }

        if (item.type == DebtType.CHEQUE && !item.isPaid && isHoliday) {
            card.tvHolidayWarning.visibility = View.VISIBLE
            card.tvHolidayWarning.text = "⚠ سررسید این چک در روز تعطیل رسمی افتاده است (روز کاری قبل اقدام کنید)"
        } else {
            card.tvHolidayWarning.visibility = View.GONE
        }

        // Bank / Payee + Sayad status for Cheques
        val metaLines = mutableListOf<String>()
        if (item.bankOrPayee.isNotBlank()) metaLines.add("بانک/در وجه: ${item.bankOrPayee}")
        if (item.type == DebtType.CHEQUE) {
            metaLines.add(if (item.isSayadRegistered) "✓ ثبت در صیاد انجام شده" else "○ ثبت در صیاد انجام نشده")
        }
        if (item.note.isNotBlank()) metaLines.add(item.note)

        if (metaLines.isEmpty()) {
            card.tvDebtMeta.visibility = View.GONE
        } else {
            card.tvDebtMeta.visibility = View.VISIBLE
            card.tvDebtMeta.text = metaLines.joinToString("  •  ")
        }

        card.btnDebtMarkPaid.text = if (item.isPaid) "برگشت به باز" else "پرداخت شد"
        card.btnDebtMarkPaid.setOnClickListener {
            FinanceRepository.togglePaid(ctx, item.id)
            AdhanScheduler.scheduleAll(ctx)
            renderAll()
        }

        card.btnDebtMore.setOnClickListener {
            val opts = mutableListOf<String>()
            if (item.type == DebtType.CHEQUE) {
                opts.add(if (item.isSayadRegistered) "لغو تیک ثبت صیاد" else "تأیید ثبت در سامانه صیاد")
            }
            opts.add("حذف همین فقره")
            if (item.installmentTotal > 1) {
                opts.add("حذف کل سری اقساط/چک‌ها")
            }
            MaterialAlertDialogBuilder(ctx)
                .setTitle(item.title)
                .setItems(opts.toTypedArray()) { _, which ->
                    val chosen = opts[which]
                    when {
                        chosen.contains("صیاد") -> FinanceRepository.toggleSayad(ctx, item.id)
                        chosen.contains("کل سری") -> FinanceRepository.deleteSeries(ctx, item.seriesId)
                        else -> FinanceRepository.deleteItem(ctx, item.id)
                    }
                    AdhanScheduler.scheduleAll(ctx)
                    renderAll()
                }
                .show()
        }

        return card.root
    }

    private fun showAddDebtDialog() {
        val ctx = requireContext()
        val today = PersianCalendarUtils.todayJalali()

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 12)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val rg = RadioGroup(ctx).apply { orientation = RadioGroup.HORIZONTAL }
        val rbInst = RadioButton(ctx).apply { text = "قسط"; isChecked = true }
        val rbCheque = RadioButton(ctx).apply { text = "چک" }
        rg.addView(rbInst)
        rg.addView(rbCheque)

        val etTitle = EditText(ctx).apply { hint = "عنوان (مثلاً: قسط وام مسکن یا چک ...)" }
        val etAmount = EditText(ctx).apply {
            hint = "مبلغ هر فقره (تومان)"
            inputType = InputType.TYPE_CLASS_NUMBER
        }

        val tvDateLabel = TextView(ctx).apply {
            text = "تاریخ شروع سررسید (شمسی: روز / ماه / سال):"
            setPadding(0, 12, 0, 4)
        }
        val dateRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val etDay = EditText(ctx).apply {
            hint = "روز"; inputType = InputType.TYPE_CLASS_NUMBER; setText(today.day.toString())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val etMonth = EditText(ctx).apply {
            hint = "ماه"; inputType = InputType.TYPE_CLASS_NUMBER; setText(today.month.toString())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val etYear = EditText(ctx).apply {
            hint = "سال"; inputType = InputType.TYPE_CLASS_NUMBER; setText(today.year.toString())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f)
        }
        dateRow.addView(etDay); dateRow.addView(etMonth); dateRow.addView(etYear)

        val tvRepeatLabel = TextView(ctx).apply {
            text = "تکرار (هر چند ماه یک‌بار؟ ۰ = یک‌باره، ۱ = ماهانه، ۲ = دوماهه، ۳ = سه‌ماهه):"
            setPadding(0, 12, 0, 4)
            textSize = 12f
        }
        val repRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val etEveryMonths = EditText(ctx).apply {
            hint = "هر چند ماه"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("1")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val etCount = EditText(ctx).apply {
            hint = "تعداد اقساط/چک"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("1")
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        repRow.addView(etEveryMonths); repRow.addView(etCount)

        val etBank = EditText(ctx).apply { hint = "نام بانک / در وجه (اختیاری)" }
        val cbSayad = CheckBox(ctx).apply {
            text = "ثبت در سامانه صیاد انجام شده"
            visibility = View.GONE
        }

        rg.setOnCheckedChangeListener { _, _ ->
            cbSayad.visibility = if (rbCheque.isChecked) View.VISIBLE else View.GONE
        }

        root.addView(rg)
        root.addView(etTitle)
        root.addView(etAmount)
        root.addView(tvDateLabel)
        root.addView(dateRow)
        root.addView(tvRepeatLabel)
        root.addView(repRow)
        root.addView(etBank)
        root.addView(cbSayad)

        val scroll = android.widget.ScrollView(ctx).apply { addView(root) }

        MaterialAlertDialogBuilder(ctx)
            .setTitle("ثبت قسط یا چک جدید")
            .setView(scroll)
            .setPositiveButton("ثبت") { _, _ ->
                val title = etTitle.text.toString().trim()
                val amount = etAmount.text.toString().replace(",", "").replace("٬", "").toLongOrNull() ?: 0L
                if (title.isBlank() || amount <= 0L) {
                    Toast.makeText(ctx, "لطفاً عنوان و مبلغ معتبر وارد کنید", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val y = etYear.text.toString().toIntOrNull() ?: today.year
                val m = (etMonth.text.toString().toIntOrNull() ?: today.month).coerceIn(1, 12)
                val maxD = PersianCalendarUtils.daysInJalaliMonth(y, m)
                val d = (etDay.text.toString().toIntOrNull() ?: today.day).coerceIn(1, maxD)
                val everyMonths = etEveryMonths.text.toString().toIntOrNull() ?: 0
                val count = etCount.text.toString().toIntOrNull() ?: 1
                val type = if (rbCheque.isChecked) DebtType.CHEQUE else DebtType.INSTALLMENT

                FinanceRepository.addSeries(
                    context = ctx,
                    type = type,
                    title = title,
                    amountToman = amount,
                    startDate = JalaliDate(y, m, d),
                    repeatEveryMonths = everyMonths,
                    count = count,
                    bankOrPayee = etBank.text.toString(),
                    isSayadRegistered = cbSayad.isChecked,
                    note = ""
                )
                AdhanScheduler.scheduleAll(ctx)
                renderAll()
                Toast.makeText(ctx, "ثبت شد و یادآورها تنظیم گردید", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }
}
