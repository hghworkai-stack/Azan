package ir.azangoo.app.ui

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.azangoo.app.databinding.ActivityTasbihBinding
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrefsManager

class TasbihActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTasbihBinding
    private lateinit var prefs: PrefsManager

    private val tasbihPresets = arrayOf(
        "تسبیحات حضرت زهرا (س)",
        "صلوات (اللهم صل علی محمد و آل محمد)",
        "استغفار (استغفرالله ربی و اتوب الیه)",
        "ذکر آزاد"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        binding = ActivityTasbihBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsManager(this)

        binding.btnTasbihBack.setOnClickListener { finish() }

        binding.btnTasbihTap.setOnClickListener { onTasbihIncrement() }

        binding.btnTasbihReset.setOnClickListener {
            prefs.tasbihCount = 0
            updateTasbihUi()
        }

        binding.btnTasbihPreset.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("انتخاب ذکر")
                .setSingleChoiceItems(tasbihPresets, prefs.tasbihPreset) { dialog, which ->
                    prefs.tasbihPreset = which
                    prefs.tasbihCount = 0
                    updateTasbihUi()
                    dialog.dismiss()
                }
                .show()
        }

        binding.switchTasbihVibrate.isChecked = prefs.tasbihVibrate
        binding.switchTasbihVibrate.setOnCheckedChangeListener { _, isChecked ->
            prefs.tasbihVibrate = isChecked
        }

        updateTasbihUi()
    }

    private fun onTasbihIncrement() {
        var count = prefs.tasbihCount + 1
        val preset = prefs.tasbihPreset
        if (preset == 0) {
            if (count > 100) count = 1
            if (prefs.tasbihVibrate) {
                val milestone = (count == 34 || count == 67 || count == 100)
                vibrateShort(if (milestone) 75L else 18L)
            }
        } else if (prefs.tasbihVibrate) {
            vibrateShort(if (count % 100 == 0) 70L else 18L)
        }
        prefs.tasbihCount = count
        updateTasbihUi()
    }

    private fun updateTasbihUi() {
        val preset = prefs.tasbihPreset
        val count = prefs.tasbihCount
        binding.btnTasbihPreset.text = "${tasbihPresets.getOrElse(preset) { tasbihPresets[0] }} ▾"

        if (preset == 0) {
            val (stageTitle, stageCount, stageMax) = when {
                count <= 34 -> Triple("الله اکبر", count, 34)
                count <= 67 -> Triple("الحمدلله", count - 34, 33)
                else -> Triple("سبحان الله", count - 67, 33)
            }
            binding.tvTasbihCurrentDhikr.text = stageTitle
            binding.tvTasbihNumber.text = PersianCalendarUtils.toPersianDigits(stageCount)
            binding.tvTasbihSubInfo.text =
                "مرحله: ${PersianCalendarUtils.toPersianDigits(stageCount)} از ${PersianCalendarUtils.toPersianDigits(stageMax)}  •  کل: ${PersianCalendarUtils.toPersianDigits(count)} از ۱۰۰"
        } else {
            binding.tvTasbihCurrentDhikr.text = when (preset) {
                1 -> "اللهم صل علی محمد و آل محمد"
                2 -> "استغفرالله ربی و اتوب الیه"
                else -> "ذکر آزاد"
            }
            binding.tvTasbihNumber.text = PersianCalendarUtils.toPersianDigits(count)
            binding.tvTasbihSubInfo.text = "تعداد کل: ${PersianCalendarUtils.toPersianDigits(count)}"
        }
    }

    private fun vibrateShort(millis: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(millis, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(millis, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(millis)
                }
            }
        } catch (_: Exception) {
        }
    }
}
