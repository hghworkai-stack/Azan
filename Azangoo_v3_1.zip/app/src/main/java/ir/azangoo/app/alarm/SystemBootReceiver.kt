package ir.azangoo.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ir.azangoo.app.widget.AzangooWidgetProvider
import ir.azangoo.app.widget.TodoWidgetProvider

class SystemBootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED -> {
                AdhanScheduler.scheduleAll(context)
                AzangooWidgetProvider.updateAllWidgets(context)
                TodoWidgetProvider.updateAllWidgets(context)
            }
        }
    }
}
