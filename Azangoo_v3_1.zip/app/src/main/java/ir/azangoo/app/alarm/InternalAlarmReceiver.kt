package ir.azangoo.app.alarm

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import ir.azangoo.app.AzangooApp
import ir.azangoo.app.R
import ir.azangoo.app.model.DebtType
import ir.azangoo.app.model.JalaliDate
import ir.azangoo.app.model.PrayerType
import ir.azangoo.app.ui.MainActivity
import ir.azangoo.app.utils.FinanceRepository
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrefsManager
import ir.azangoo.app.widget.AzangooWidgetProvider
import ir.azangoo.app.widget.TodoWidgetProvider

class InternalAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            AdhanScheduler.ACTION_PLAY_ADHAN -> {
                val prayerKey = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_KEY)
                val prayerTime = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_TIME) ?: ""
                val serviceIntent = Intent(context, AdhanPlaybackService::class.java).apply {
                    action = AdhanPlaybackService.ACTION_START
                    putExtra(AdhanScheduler.EXTRA_PRAYER_KEY, prayerKey)
                    putExtra(AdhanScheduler.EXTRA_PRAYER_TIME, prayerTime)
                }
                ContextCompat.startForegroundService(context, serviceIntent)
                AdhanScheduler.scheduleAll(context)
                AzangooWidgetProvider.updateAllWidgets(context)
            }

            AdhanScheduler.ACTION_PRE_ADHAN -> {
                val prayerType = PrayerType.fromKey(intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_KEY))
                val prayerTime = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_TIME) ?: ""
                val mins = intent.getIntExtra(AdhanScheduler.EXTRA_PRE_MINUTES, 10)
                showPreAdhanNotification(context, prayerType, prayerTime, mins)
            }

            AdhanScheduler.ACTION_FINANCE_CHECK -> {
                checkAndNotifyFinanceItems(context)
                AdhanScheduler.scheduleAll(context)
            }

            AdhanScheduler.ACTION_TODO_REMINDER -> {
                val title = intent.getStringExtra(AdhanScheduler.EXTRA_TODO_TITLE) ?: "یادآور کار"
                val id = intent.getStringExtra(AdhanScheduler.EXTRA_TODO_ID) ?: "todo"
                showTodoNotification(context, id, title)
            }

            AdhanScheduler.ACTION_REFRESH_WIDGET -> {
                AdhanScheduler.scheduleAll(context)
                AzangooWidgetProvider.updateAllWidgets(context)
                TodoWidgetProvider.updateAllWidgets(context)
            }
        }
    }

    private fun checkAndNotifyFinanceItems(context: Context) {
        val prefs = PrefsManager(context)
        val today = PersianCalendarUtils.todayJalali()
        val instBefore = prefs.installmentRemindDaysBefore
        val chequeBefore = prefs.chequeRemindDaysBefore
        val items = FinanceRepository.getAllItems(context).filter { !it.isPaid }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        var notifIndex = 8100
        for (item in items) {
            val due = JalaliDate(item.dueYear, item.dueMonth, item.dueDay)
            val daysLeft = PersianCalendarUtils.daysBetweenJalali(today, due)

            val shouldNotify = when (item.type) {
                DebtType.INSTALLMENT -> (daysLeft == 0 || daysLeft == instBefore)
                DebtType.CHEQUE -> (daysLeft == 0 || daysLeft == 3 || daysLeft == chequeBefore)
            }
            if (!shouldNotify) continue

            val dayText = when (daysLeft) {
                0 -> "امروز سررسید است!"
                else -> "${PersianCalendarUtils.toPersianDigits(daysLeft)} روز تا سررسید"
            }
            val title = "یادآور ${item.type.persianName}: ${item.title}"
            val amountStr = if (prefs.hideFinanceAmounts) "•••••" else PersianCalendarUtils.formatToman(item.amountToman)
            val body = "$dayText • مبلغ: $amountStr"

            val openIntent = Intent(context, MainActivity::class.java).apply {
                putExtra(MainActivity.EXTRA_OPEN_TAB, R.id.nav_finance)
            }
            val pi = PendingIntent.getActivity(
                context,
                notifIndex,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Generic public version shown on Lock Screen (no amounts or titles leaked)
            val publicVersion = NotificationCompat.Builder(context, AzangooApp.CHANNEL_FINANCE_ID)
                .setSmallIcon(R.drawable.ic_finance)
                .setContentTitle("اذانگو")
                .setContentText("یادآور مالی جدید (برای مشاهده قفل گوشی را باز کنید)")
                .build()

            val notif = NotificationCompat.Builder(context, AzangooApp.CHANNEL_FINANCE_ID)
                .setSmallIcon(R.drawable.ic_finance)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
                .setPublicVersion(publicVersion)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            nm.notify(notifIndex++, notif)
        }
    }

    private fun showTodoNotification(context: Context, taskId: String, taskTitle: String) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            putExtra(MainActivity.EXTRA_OPEN_TAB, R.id.nav_todo)
        }
        val notifId = 8500 + (taskId.hashCode() and 0x03FF)
        val pi = PendingIntent.getActivity(
            context,
            notifId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val publicVersion = NotificationCompat.Builder(context, AzangooApp.CHANNEL_TODO_ID)
            .setSmallIcon(R.drawable.ic_todo)
            .setContentTitle("اذانگو")
            .setContentText("یادآور کار جدید (برای مشاهده قفل گوشی را باز کنید)")
            .build()

        val notif = NotificationCompat.Builder(context, AzangooApp.CHANNEL_TODO_ID)
            .setSmallIcon(R.drawable.ic_todo)
            .setContentTitle("یادآور کار")
            .setContentText(taskTitle)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(notifId, notif)
    }

    private fun showPreAdhanNotification(context: Context, type: PrayerType, timeFormatted: String, mins: Int) {
        val openIntent = Intent(context, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            context,
            8800 + type.ordinal,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(context, AzangooApp.CHANNEL_PREADHAN_ID)
            .setSmallIcon(R.drawable.ic_mosque)
            .setContentTitle("${PersianCalendarUtils.toPersianDigits(mins)} دقیقه تا ${type.persianName}")
            .setContentText("وقت ${type.persianName} به افق تهران: ساعت ${PersianCalendarUtils.toPersianDigits(timeFormatted)}")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(7800 + type.ordinal, notif)
    }
}
