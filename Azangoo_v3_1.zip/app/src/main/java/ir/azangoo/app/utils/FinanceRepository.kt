package ir.azangoo.app.utils

import android.content.Context
import ir.azangoo.app.model.DebtItem
import ir.azangoo.app.model.DebtType
import ir.azangoo.app.model.JalaliDate
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

object FinanceRepository {

    private const val FILE_NAME = "azangoo_finance.json"

    private fun dataFile(context: Context): File = File(context.applicationContext.filesDir, FILE_NAME)

    @Synchronized
    fun loadRawJson(context: Context): JSONObject {
        val f = dataFile(context)
        return try {
            val txt = SecureStorage.readEncryptedText(f); if (txt != null) JSONObject(txt) else JSONObject().put("items", JSONArray())
        } catch (_: Exception) {
            JSONObject().put("items", JSONArray())
        }
    }

    @Synchronized
    fun saveRawJson(context: Context, root: JSONObject) {
        try {
            SecureStorage.writeEncryptedText(dataFile(context), root.toString())
        } catch (_: Exception) {
        }
    }

    fun getAllItems(context: Context): List<DebtItem> {
        val root = loadRawJson(context)
        val arr = root.optJSONArray("items") ?: return emptyList()
        val list = mutableListOf<DebtItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                DebtItem(
                    id = o.getString("id"),
                    seriesId = o.optString("seriesId", o.getString("id")),
                    type = DebtType.fromKey(o.optString("type", "installment")),
                    title = o.getString("title"),
                    amountToman = o.optLong("amountToman", 0L),
                    dueYear = o.getInt("dueYear"),
                    dueMonth = o.getInt("dueMonth"),
                    dueDay = o.getInt("dueDay"),
                    installmentIndex = o.optInt("installmentIndex", 1),
                    installmentTotal = o.optInt("installmentTotal", 1),
                    isPaid = o.optBoolean("isPaid", false),
                    bankOrPayee = o.optString("bankOrPayee", ""),
                    isSayadRegistered = o.optBoolean("isSayadRegistered", false),
                    note = o.optString("note", "")
                )
            )
        }
        return list.sortedWith(compareBy<DebtItem> { it.isPaid }.thenBy { it.dueDateKey })
    }

    fun getItemsForDate(context: Context, dateKey: String): List<DebtItem> {
        return getAllItems(context).filter { it.dueDateKey == dateKey }
    }

    fun addSeries(
        context: Context,
        type: DebtType,
        title: String,
        amountToman: Long,
        startDate: JalaliDate,
        repeatEveryMonths: Int, // 0 = one-time, 1 = monthly, 2 = bi-monthly, 3 = quarterly, etc.
        count: Int,
        bankOrPayee: String,
        isSayadRegistered: Boolean,
        note: String
    ) {
        val safeCount = if (repeatEveryMonths <= 0) 1 else count.coerceIn(1, 120)
        val seriesId = "ser_${UUID.randomUUID().toString().take(8)}"
        val existing = getAllItems(context).toMutableList()

        for (i in 0 until safeCount) {
            val due = if (i == 0) startDate else PersianCalendarUtils.addMonthsJalali(startDate, i * repeatEveryMonths)
            existing.add(
                DebtItem(
                    id = "debt_${UUID.randomUUID().toString().take(8)}",
                    seriesId = seriesId,
                    type = type,
                    title = title.trim(),
                    amountToman = amountToman,
                    dueYear = due.year,
                    dueMonth = due.month,
                    dueDay = due.day,
                    installmentIndex = i + 1,
                    installmentTotal = safeCount,
                    isPaid = false,
                    bankOrPayee = bankOrPayee.trim(),
                    isSayadRegistered = isSayadRegistered,
                    note = note.trim()
                )
            )
        }
        saveAll(context, existing)
    }

    fun togglePaid(context: Context, itemId: String) {
        val items = getAllItems(context).toMutableList()
        val idx = items.indexOfFirst { it.id == itemId }
        if (idx >= 0) {
            items[idx] = items[idx].copy(isPaid = !items[idx].isPaid)
            saveAll(context, items)
        }
    }

    fun toggleSayad(context: Context, itemId: String) {
        val items = getAllItems(context).toMutableList()
        val idx = items.indexOfFirst { it.id == itemId }
        if (idx >= 0) {
            items[idx] = items[idx].copy(isSayadRegistered = !items[idx].isSayadRegistered)
            saveAll(context, items)
        }
    }

    fun deleteItem(context: Context, itemId: String) {
        saveAll(context, getAllItems(context).filter { it.id != itemId })
    }

    fun deleteSeries(context: Context, seriesId: String) {
        saveAll(context, getAllItems(context).filter { it.seriesId != seriesId })
    }

    private fun saveAll(context: Context, items: List<DebtItem>) {
        val arr = JSONArray()
        for (item in items) {
            arr.put(JSONObject().apply {
                put("id", item.id)
                put("seriesId", item.seriesId)
                put("type", item.type.key)
                put("title", item.title)
                put("amountToman", item.amountToman)
                put("dueYear", item.dueYear)
                put("dueMonth", item.dueMonth)
                put("dueDay", item.dueDay)
                put("installmentIndex", item.installmentIndex)
                put("installmentTotal", item.installmentTotal)
                put("isPaid", item.isPaid)
                put("bankOrPayee", item.bankOrPayee)
                put("isSayadRegistered", item.isSayadRegistered)
                put("note", item.note)
            })
        }
        saveRawJson(context, JSONObject().put("items", arr))
    }
}
