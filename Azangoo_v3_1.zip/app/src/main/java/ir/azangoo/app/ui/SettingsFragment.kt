package ir.azangoo.app.ui

import android.app.AlarmManager
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.azangoo.app.R
import ir.azangoo.app.alarm.AdhanPlaybackService
import ir.azangoo.app.alarm.AdhanScheduler
import ir.azangoo.app.databinding.FragmentSettingsBinding
import ir.azangoo.app.utils.BackupManager
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrefsManager
import ir.azangoo.app.widget.AzangooWidgetProvider
import ir.azangoo.app.widget.TodoWidgetProvider

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    private lateinit var prefs: PrefsManager
    private var pendingEncryptedBackupContent: String? = null

    private val exportBackupLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        val content = pendingEncryptedBackupContent
        pendingEncryptedBackupContent = null
        if (uri != null && content != null) {
            try {
                requireContext().contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(content.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(requireContext(), "فایل بکاپ رمزنگاری‌شده با موفقیت ذخیره شد", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "خطا در ذخیره فایل: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val importBackupLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val raw = requireContext().contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (raw.isNullOrBlank()) {
                    Toast.makeText(requireContext(), "فایل انتخاب‌شده خالی است", Toast.LENGTH_SHORT).show()
                } else {
                    promptPasswordAndRestore(raw)
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "خطا در خواندن فایل: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PrefsManager(requireContext())

        binding.btnOpenAdhanLibrary.setOnClickListener {
            startActivity(Intent(requireContext(), AdhanLibraryActivity::class.java))
        }

        binding.btnTestAudio.setOnClickListener {
            val ctx = requireContext()
            if (AdhanPlaybackService.isPlaying) {
                AdhanPlaybackService.stopPlayback(ctx)
            } else {
                AdhanPlaybackService.startPreview(ctx, prefs.selectedAdhanFile, prefs.selectedAdhanTitle)
                Toast.makeText(ctx, "برای قطع پخش، روی اعلان یا دکمه توقف بزنید", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnStopTestAudio.setOnClickListener {
            AdhanPlaybackService.stopPlayback(requireContext())
        }

        binding.switchFajr.isChecked = prefs.fajrEnabled
        binding.switchDhuhr.isChecked = prefs.dhuhrEnabled
        binding.switchMaghrib.isChecked = prefs.maghribEnabled
        binding.switchAlarmStream.isChecked = prefs.useAlarmStream
        binding.switchFadeIn.isChecked = prefs.fadeInEnabled
        binding.switchFlagSecure.isChecked = prefs.flagSecureEnabled

        binding.switchFajr.setOnCheckedChangeListener { _, isChecked ->
            prefs.fajrEnabled = isChecked; AdhanScheduler.scheduleAll(requireContext())
        }
        binding.switchDhuhr.setOnCheckedChangeListener { _, isChecked ->
            prefs.dhuhrEnabled = isChecked; AdhanScheduler.scheduleAll(requireContext())
        }
        binding.switchMaghrib.setOnCheckedChangeListener { _, isChecked ->
            prefs.maghribEnabled = isChecked; AdhanScheduler.scheduleAll(requireContext())
        }
        binding.switchAlarmStream.setOnCheckedChangeListener { _, isChecked -> prefs.useAlarmStream = isChecked }
        binding.switchFadeIn.setOnCheckedChangeListener { _, isChecked -> prefs.fadeInEnabled = isChecked }

        binding.switchFlagSecure.setOnCheckedChangeListener { _, isChecked ->
            prefs.flagSecureEnabled = isChecked
            (activity as? MainActivity)?.applyFlagSecure()
        }

        binding.btnBiometricLock.setOnClickListener {
            val options = arrayOf("خاموش", "قفل اثر انگشت/رمز فقط برای بخش مالی", "قفل اثر انگشت/رمز برای کل برنامه")
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("قفل امنیتی برنامه")
                .setSingleChoiceItems(options, prefs.biometricLockMode) { dialog, which ->
                    prefs.biometricLockMode = which
                    updateBiometricLabel()
                    dialog.dismiss()
                }
                .show()
        }

        binding.sliderVolume.value = prefs.adhanVolumePercent.toFloat()
        updateVolumeLabel(prefs.adhanVolumePercent)
        binding.sliderVolume.addOnChangeListener { _, value, _ ->
            val pct = value.toInt()
            prefs.adhanVolumePercent = pct
            updateVolumeLabel(pct)
        }

        binding.btnPreAdhanSelector.setOnClickListener {
            val options = arrayOf("خاموش", "۵ دقیقه قبل", "۱۰ دقیقه قبل", "۱۵ دقیقه قبل")
            val values = intArrayOf(0, 5, 10, 15)
            val currentIdx = values.indexOf(prefs.preAdhanMinutes).coerceAtLeast(0)
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("یادآور پیش‌اذان")
                .setSingleChoiceItems(options, currentIdx) { dialog, which ->
                    prefs.preAdhanMinutes = values[which]
                    AdhanScheduler.scheduleAll(requireContext())
                    updatePreAdhanLabel()
                    dialog.dismiss()
                }
                .show()
        }

        binding.btnFinanceReminderTime.setOnClickListener {
            TimePickerDialog(
                requireContext(),
                { _, hour, minute ->
                    prefs.financeReminderHour = hour
                    prefs.financeReminderMinute = minute
                    AdhanScheduler.scheduleAll(requireContext())
                    updateFinanceTimeLabel()
                },
                prefs.financeReminderHour,
                prefs.financeReminderMinute,
                true
            ).show()
        }

        binding.btnBackupCopy.setOnClickListener {
            promptPasswordAndExport()
        }

        binding.btnBackupRestore.setOnClickListener {
            importBackupLauncher.launch(arrayOf("*/*"))
        }

        binding.btnThemeSelector.setOnClickListener {
            val options = arrayOf("مطابق تم گوشی (خودکار)", "تم روشن", "تم تیره")
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("ظاهر برنامه")
                .setSingleChoiceItems(options, prefs.themeMode) { dialog, which ->
                    prefs.themeMode = which
                    updateThemeLabel()
                    val mode = when (which) {
                        1 -> AppCompatDelegate.MODE_NIGHT_NO
                        2 -> AppCompatDelegate.MODE_NIGHT_YES
                        else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                    }
                    AppCompatDelegate.setDefaultNightMode(mode)
                    dialog.dismiss()
                }
                .show()
        }

        binding.btnHijriMinus.setOnClickListener {
            prefs.hijriOffsetDays = (prefs.hijriOffsetDays - 1).coerceAtLeast(-2)
            updateHijriOffsetUi()
            AzangooWidgetProvider.updateAllWidgets(requireContext())
        }
        binding.btnHijriPlus.setOnClickListener {
            prefs.hijriOffsetDays = (prefs.hijriOffsetDays + 1).coerceAtMost(2)
            updateHijriOffsetUi()
            AzangooWidgetProvider.updateAllWidgets(requireContext())
        }

        binding.btnBatteryOptimization.setOnClickListener { openBatteryOptimizationSettings() }
        binding.btnExactAlarm.setOnClickListener { openExactAlarmSettings() }

        updatePreAdhanLabel()
        updateFinanceTimeLabel()
        updateThemeLabel()
        updateBiometricLabel()
        updateHijriOffsetUi()
    }

    private fun promptPasswordAndExport() {
        val ctx = requireContext()
        val etPass = EditText(ctx).apply {
            hint = "یک رمز عبور برای رمزنگاری فایل بکاپ وارد کنید (حداقل ۴ کاراکتر)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val box = LinearLayout(ctx).apply {
            setPadding(48, 24, 48, 8)
            addView(etPass)
        }
        MaterialAlertDialogBuilder(ctx)
            .setTitle("ساخت فایل بکاپ رمزنگاری‌شده (AES-256)")
            .setView(box)
            .setPositiveButton("ذخیره فایل .azg") { _, _ ->
                val pass = etPass.text.toString()
                val res = BackupManager.exportEncryptedBackup(ctx, pass)
                res.onSuccess { encrypted ->
                    pendingEncryptedBackupContent = encrypted
                    val dateTag = PersianCalendarUtils.todayDateKey()
                    exportBackupLauncher.launch("Azangoo_Backup_$dateTag.azg")
                }.onFailure { err ->
                    Toast.makeText(ctx, err.message ?: "خطا در رمزنگاری", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun promptPasswordAndRestore(rawContent: String) {
        val ctx = requireContext()
        val etPass = EditText(ctx).apply {
            hint = "رمز عبور فایل بکاپ را وارد کنید"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val box = LinearLayout(ctx).apply {
            setPadding(48, 24, 48, 8)
            addView(etPass)
        }
        MaterialAlertDialogBuilder(ctx)
            .setTitle("رمزگشایی و بازیابی بکاپ")
            .setView(box)
            .setPositiveButton("بازیابی") { _, _ ->
                val res = BackupManager.importEncryptedBackup(ctx, rawContent, etPass.text.toString())
                res.onSuccess {
                    AdhanScheduler.scheduleAll(ctx)
                    TodoWidgetProvider.updateAllWidgets(ctx)
                    Toast.makeText(ctx, "اطلاعات با موفقیت رمزگشایی و بازیابی شد", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    Toast.makeText(ctx, err.message ?: "رمز عبور اشتباه است", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        binding.tvSelectedAudio.text = "صدای فعال: ${prefs.selectedAdhanTitle}"
        binding.switchFajr.isChecked = prefs.fajrEnabled
        binding.switchDhuhr.isChecked = prefs.dhuhrEnabled
        binding.switchMaghrib.isChecked = prefs.maghribEnabled
        updatePermissionStatuses()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun updateVolumeLabel(pct: Int) {
        binding.tvVolumeValue.text = "${PersianCalendarUtils.toPersianDigits(pct)}٪"
    }

    private fun updatePreAdhanLabel() {
        val m = prefs.preAdhanMinutes
        binding.btnPreAdhanSelector.text = if (m <= 0) "یادآور پیش‌اذان: خاموش"
        else "یادآور پیش‌اذان: ${PersianCalendarUtils.toPersianDigits(m)} دقیقه قبل"
    }

    private fun updateFinanceTimeLabel() {
        val t = String.format("%02d:%02d", prefs.financeReminderHour, prefs.financeReminderMinute)
        binding.btnFinanceReminderTime.text = "ساعت یادآور اقساط و چک: ${PersianCalendarUtils.toPersianDigits(t)}"
    }

    private fun updateBiometricLabel() {
        binding.btnBiometricLock.text = when (prefs.biometricLockMode) {
            1 -> "قفل اثر انگشت/رمز: فقط بخش مالی"
            2 -> "قفل اثر انگشت/رمز: کل برنامه"
            else -> "قفل اثر انگشت/رمز: خاموش"
        }
    }

    private fun updateThemeLabel() {
        binding.btnThemeSelector.text = when (prefs.themeMode) {
            1 -> "تم برنامه: روشن"
            2 -> "تم برنامه: تیره"
            else -> "تم برنامه: مطابق گوشی (خودکار)"
        }
    }

    private fun updateHijriOffsetUi() {
        val offset = prefs.hijriOffsetDays
        binding.tvHijriOffsetValue.text = when {
            offset > 0 -> "+${PersianCalendarUtils.toPersianDigits(offset)} روز"
            offset < 0 -> "${PersianCalendarUtils.toPersianDigits(offset)} روز"
            else -> "۰ (پیش‌فرض)"
        }
    }

    private fun updatePermissionStatuses() {
        val ctx = requireContext()
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val ignoringBattery = pm.isIgnoringBatteryOptimizations(ctx.packageName)
        binding.tvBatteryStatus.text = if (ignoringBattery) "وضعیت باتری: بدون محدودیت (عالی)"
        else "وضعیت باتری: محدودیت فعال است (توصیه می‌شود غیرفعال کنید)"
        binding.tvBatteryStatus.setTextColor(
            ContextCompat.getColor(ctx, if (ignoringBattery) R.color.azangoo_primary else R.color.azangoo_holiday)
        )

        val alarmManager = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) alarmManager.canScheduleExactAlarms() else true
        binding.tvExactAlarmStatus.text = if (canExact) "وضعیت آلارم دقیق: فعال" else "وضعیت آلارم دقیق: نیاز به مجوز"
        binding.tvExactAlarmStatus.setTextColor(
            ContextCompat.getColor(ctx, if (canExact) R.color.azangoo_primary else R.color.azangoo_holiday)
        )
    }

    private fun openBatteryOptimizationSettings() {
        val ctx = requireContext()
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${ctx.packageName}")
            })
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) { }
        }
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:${requireContext().packageName}")
                })
            } catch (_: Exception) { }
        } else {
            Toast.makeText(requireContext(), "آلارم دقیق در این نسخه اندروید خودکار فعال است.", Toast.LENGTH_SHORT).show()
        }
    }
}
