package ir.azangoo.app.utils

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Password-encrypted offline backup (.azg) using PBKDF2WithHmacSHA256 (120k iterations) + AES-256-GCM.
 */
object BackupManager {

    private const val FORMAT_TAG = "AZG_ENC_BACKUP_V1"
    private const val PBKDF2_ITERATIONS = 120_000
    private const val KEY_LENGTH_BITS = 256
    private const val GCM_TAG_BITS = 128

    fun exportEncryptedBackup(context: Context, password: String): Result<String> {
        if (password.length < 4) {
            return Result.failure(IllegalArgumentException("رمز عبور باید حداقل ۴ کاراکتر باشد"))
        }
        return try {
            val payload = JSONObject().apply {
                put("app", "Azangoo")
                put("version", 3)
                put("todos", TodoRepository.loadRawJson(context))
                put("finance", FinanceRepository.loadRawJson(context))
            }.toString()

            val random = SecureRandom()
            val salt = ByteArray(16).also { random.nextBytes(it) }
            val iv = ByteArray(12).also { random.nextBytes(it) }
            val key = deriveKey(password, salt)

            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
            val encrypted = cipher.doFinal(payload.toByteArray(Charsets.UTF_8))

            val envelope = JSONObject().apply {
                put("format", FORMAT_TAG)
                put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                put("iv", Base64.encodeToString(iv, Base64.NO_WRAP))
                put("data", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            }.toString()

            Result.success(envelope)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun importEncryptedBackup(context: Context, rawContent: String, password: String): Result<Unit> {
        return try {
            val envelope = JSONObject(rawContent.trim())
            if (envelope.optString("format") != FORMAT_TAG) {
                return Result.failure(IllegalArgumentException("فایل انتخاب‌شده بکاپ رمزنگاری‌شده معتبر اذانگو نیست"))
            }
            val salt = Base64.decode(envelope.getString("salt"), Base64.NO_WRAP)
            val iv = Base64.decode(envelope.getString("iv"), Base64.NO_WRAP)
            val encrypted = Base64.decode(envelope.getString("data"), Base64.NO_WRAP)

            val key = deriveKey(password, salt)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
            val plainBytes = cipher.doFinal(encrypted)
            val root = JSONObject(String(plainBytes, Charsets.UTF_8))

            if (root.optString("app") != "Azangoo") {
                return Result.failure(IllegalArgumentException("محتوای بکاپ نامعتبر است"))
            }
            root.optJSONObject("todos")?.let { TodoRepository.saveRawJson(context, it) }
            root.optJSONObject("finance")?.let { FinanceRepository.saveRawJson(context, it) }
            Result.success(Unit)
        } catch (_: javax.crypto.AEADBadTagException) {
            Result.failure(IllegalArgumentException("رمز عبور اشتباه است یا فایل بکاپ دستکاری شده است"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun deriveKey(password: String, salt: ByteArray): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(password.toCharArray(), salt, PBKDF2_ITERATIONS, KEY_LENGTH_BITS)
        val secret = factory.generateSecret(spec)
        return SecretKeySpec(secret.encoded, "AES")
    }
}
