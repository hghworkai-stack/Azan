package ir.azangoo.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews
import ir.azangoo.app.R
import ir.azangoo.app.alarm.AdhanScheduler
import ir.azangoo.app.ui.MainActivity
import ir.azangoo.app.utils.PrefsManager
import ir.azangoo.app.utils.TodoRepository

class TodoWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_TOGGLE_TASK = "ir.azangoo.app.WIDGET_TOGGLE_TASK"
        const val EXTRA_TASK_ID = "extra_task_id"

        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, TodoWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                for (id in ids) {
                    updateAppWidget(context, manager, id)
                }
                manager.notifyAppWidgetViewDataChanged(ids, R.id.todo_widget_list)
            }
        }

        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val prefs = PrefsManager(context)
            val listId = prefs.getTodoWidgetListId(appWidgetId)
            val listTitle = prefs.getTodoWidgetListTitle(appWidgetId)

            val views = RemoteViews(context.packageName, R.layout.widget_todo)
            views.setTextViewText(R.id.tv_todo_widget_title, listTitle)

            // Attach RemoteViewsService for scrollable list
            val svcIntent = Intent(context, TodoWidgetService::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
                data = Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
            }
            views.setRemoteAdapter(R.id.todo_widget_list, svcIntent)
            views.setEmptyView(R.id.todo_widget_list, R.id.tv_todo_widget_empty)

            // Template PendingIntent for tapping any task row to check it off
            val toggleIntent = Intent(context, TodoWidgetProvider::class.java).apply {
                action = ACTION_TOGGLE_TASK
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            }
            val togglePi = PendingIntent.getBroadcast(
                context,
                4000 + appWidgetId,
                toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            views.setPendingIntentTemplate(R.id.todo_widget_list, togglePi)

            // Tap "+" to open MainActivity directly on To-Do tab with quick-add for this list
            val addIntent = Intent(context, MainActivity::class.java).apply {
                putExtra(MainActivity.EXTRA_OPEN_TAB, R.id.nav_todo)
                putExtra(MainActivity.EXTRA_TODO_LIST_ID, listId)
                putExtra(MainActivity.EXTRA_QUICK_ADD_TODO, true)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val addPi = PendingIntent.getActivity(
                context,
                4200 + appWidgetId,
                addIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.btn_todo_widget_add, addPi)

            // Tap title to reconfigure which list this widget displays
            val configIntent = Intent(context, TodoWidgetConfigActivity::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val configPi = PendingIntent.getActivity(
                context,
                4400 + appWidgetId,
                configIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.tv_todo_widget_title, configPi)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, id)
        }
        appWidgetManager.notifyAppWidgetViewDataChanged(appWidgetIds, R.id.todo_widget_list)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        val prefs = PrefsManager(context)
        for (id in appWidgetIds) {
            prefs.removeTodoWidget(id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE_TASK) {
            val taskId = intent.getStringExtra(EXTRA_TASK_ID)
            if (!taskId.isNullOrBlank()) {
                TodoRepository.toggleTaskCompleted(context, taskId)
                AdhanScheduler.scheduleAll(context)
                updateAllWidgets(context)
            }
        }
    }
}
