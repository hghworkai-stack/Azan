package ir.azangoo.app.widget

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import ir.azangoo.app.R
import ir.azangoo.app.model.TodoTask
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrefsManager
import ir.azangoo.app.utils.TodoRepository

class TodoWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory {
        val widgetId = intent.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        )
        return TodoRemoteViewsFactory(applicationContext, widgetId)
    }
}

class TodoRemoteViewsFactory(
    private val context: Context,
    private val widgetId: Int
) : RemoteViewsService.RemoteViewsFactory {

    private var tasks: List<TodoTask> = emptyList()

    override fun onCreate() = Unit

    override fun onDataSetChanged() {
        val listId = PrefsManager(context).getTodoWidgetListId(widgetId)
        tasks = TodoRepository.getTasksForFilter(context, listId).filter { !it.isCompleted }
    }

    override fun onDestroy() {
        tasks = emptyList()
    }

    override fun getCount(): Int = tasks.size

    override fun getViewAt(position: Int): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.item_widget_todo)
        if (position < 0 || position >= tasks.size) return views

        val task = tasks[position]
        views.setTextViewText(R.id.tv_wt_title, task.title)

        val metaParts = mutableListOf<String>()
        task.dueDateKey?.let { key ->
            PersianCalendarUtils.parseDateKey(key)?.let { j ->
                metaParts.add(PersianCalendarUtils.formatJalaliShort(j))
            }
        }
        if (task.steps.isNotEmpty()) {
            val done = task.steps.count { it.isDone }
            metaParts.add("${PersianCalendarUtils.toPersianDigits(done)}/${PersianCalendarUtils.toPersianDigits(task.steps.size)} مرحله")
        }

        if (metaParts.isEmpty()) {
            views.setViewVisibility(R.id.tv_wt_meta, View.GONE)
        } else {
            views.setViewVisibility(R.id.tv_wt_meta, View.VISIBLE)
            views.setTextViewText(R.id.tv_wt_meta, metaParts.joinToString(" • "))
        }

        views.setViewVisibility(R.id.iv_wt_star, if (task.isImportant) View.VISIBLE else View.GONE)

        val fillIn = Intent().apply {
            putExtra(TodoWidgetProvider.EXTRA_TASK_ID, task.id)
        }
        views.setOnClickFillInIntent(R.id.wt_row_root, fillIn)
        return views
    }

    override fun getLoadingView(): RemoteViews? = null
    override fun getViewTypeCount(): Int = 1
    override fun getItemId(position: Int): Long = position.toLong()
    override fun hasStableIds(): Boolean = false
}
