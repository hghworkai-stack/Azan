package ir.azangoo.app.widget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import ir.azangoo.app.databinding.ActivityTodoWidgetConfigBinding
import ir.azangoo.app.utils.PrefsManager
import ir.azangoo.app.utils.TodoRepository

class TodoWidgetConfigActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTodoWidgetConfigBinding
    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        setResult(Activity.RESULT_CANCELED)

        appWidgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        binding = ActivityTodoWidgetConfigBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val options = mutableListOf(
            Pair(TodoRepository.LIST_MY_DAY, "روز من"),
            Pair(TodoRepository.LIST_IMPORTANT, "مهم (ستاره‌دار)"),
            Pair(TodoRepository.LIST_PLANNED, "برنامه‌ریزی‌شده"),
            Pair(TodoRepository.LIST_ALL, "همه کارها")
        )
        for (custom in TodoRepository.getCustomLists(this)) {
            options.add(Pair(custom.id, "لیست: ${custom.name}"))
        }

        val labels = options.map { it.second }
        binding.lvWidgetLists.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        binding.lvWidgetLists.setOnItemClickListener { _, _, position, _ ->
            val chosen = options[position]
            val cleanTitle = chosen.second.removePrefix("لیست: ")
            PrefsManager(this).setTodoWidgetList(appWidgetId, chosen.first, cleanTitle)

            val mgr = AppWidgetManager.getInstance(this)
            TodoWidgetProvider.updateAppWidget(this, mgr, appWidgetId)
            mgr.notifyAppWidgetViewDataChanged(appWidgetId, ir.azangoo.app.R.id.todo_widget_list)

            val result = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            setResult(Activity.RESULT_OK, result)
            finish()
        }
    }
}
