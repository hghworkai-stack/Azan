package ir.azangoo.app.model

data class TodoListModel(
    val id: String,
    val name: String,
    val colorHex: String = "#0F766E"
)

data class TodoStep(
    val id: String,
    val title: String,
    val isDone: Boolean = false
)

enum class TodoRepeatType(val key: String, val persianLabel: String) {
    NONE("none", "بدون تکرار"),
    DAILY("daily", "روزانه"),
    WEEKLY("weekly", "هفتگی"),
    MONTHLY("monthly", "ماهانه"),
    YEARLY("yearly", "سالانه");

    companion object {
        fun fromKey(k: String?): TodoRepeatType = entries.firstOrNull { it.key == k } ?: NONE
    }
}

data class TodoTask(
    val id: String,
    val listId: String,
    val title: String,
    val note: String = "",
    val isCompleted: Boolean = false,
    val isImportant: Boolean = false,
    val myDayDateKey: String? = null, // "YYYY-MM-DD" Jalali if added to My Day
    val dueDateKey: String? = null,   // "YYYY-MM-DD" Jalali
    val reminderTime: String? = null, // "HH:mm"
    val repeatType: TodoRepeatType = TodoRepeatType.NONE,
    val steps: List<TodoStep> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
)
