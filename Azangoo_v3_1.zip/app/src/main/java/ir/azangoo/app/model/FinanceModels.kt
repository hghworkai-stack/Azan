package ir.azangoo.app.model

enum class DebtType(val key: String, val persianName: String) {
    INSTALLMENT("installment", "قسط"),
    CHEQUE("cheque", "چک");

    companion object {
        fun fromKey(k: String?): DebtType = entries.firstOrNull { it.key == k } ?: INSTALLMENT
    }
}

data class DebtItem(
    val id: String,
    val seriesId: String,
    val type: DebtType,
    val title: String,
    val amountToman: Long,
    val dueYear: Int,
    val dueMonth: Int,
    val dueDay: Int,
    val installmentIndex: Int = 1,
    val installmentTotal: Int = 1,
    val isPaid: Boolean = false,
    val bankOrPayee: String = "",
    val isSayadRegistered: Boolean = false,
    val note: String = ""
) {
    val dueDateKey: String get() = String.format("%04d-%02d-%02d", dueYear, dueMonth, dueDay)
}
