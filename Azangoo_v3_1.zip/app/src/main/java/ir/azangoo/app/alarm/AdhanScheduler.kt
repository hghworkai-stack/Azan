package ir.azangoo.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import ir.azangoo.app.model.GregorianDate
import ir.azangoo.app.model.PrayerType
import ir.azangoo.app.ui.MainActivity
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.PrayerTimeCalculator
import ir.azangoo.app.utils.PrefsManager
import ir.azangoo.app.utils.TodoRepository
import java.util.Calendar

object AdhanScheduler {

    const val ACTION_PLAY_ADHAN = "ir.azangoo.app.ACTION_PLAY_ADHAN"
    const val ACTION_PRE_ADHAN = "ir.azangoo.app.ACTION_PRE_ADHAN"
    const val ACTION_FINANCE_CHECK = "ir.azangoo.app.ACTION_FINANCE_CHECK"
    const val ACTION_TODO_REMINDER = "ir.azangoo.app.ACTION_TODO_REMINDER"
    const val ACTION_REFRESH_WIDGET = "ir.azangoo.app.ACTION_REFRESH_WIDGET"

    const val EXTRA_PRAYER_KEY = "extra_prayer_key"
    const val EXTRA_PRAYER_TIME = "extra_prayer_time"
    const val EXTRA_PRE_MINUTES = "extra_pre_minutes"
    const val EXTRA_TODO_ID = "extra_todo_id"
    const val EXTRA_TODO_TITLE = "extra_todo_title"

    private const val WIDGET_REFRESH_REQ_CODE = 2099
    private const val FINANCE_CHECK_REQ_CODE = 2199

    fun scheduleAll(context: Context) {
        val prefs = PrefsManager(context)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        listOf(PrayerType.FAJR, PrayerType.DHUHR, PrayerType.MAGHRIB).forEach { type ->
            cancelAlarm(context, alarmManager, type.alarmId, ACTION_PLAY_ADHAN)
            cancelAlarm(context, alarmManager, type.preAlarmId, ACTION_PRE_ADHAN)
        }

        val now = Calendar.getInstance()
        val today = GregorianDate(now.get(Calendar.YEAR), now.get(Calendar.MONTH) + 1, now.get(Calendar.DAY_OF_MONTH))
        val tomorrowCal = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
        val tomorrow = GregorianDate(
            tomorrowCal.get(Calendar.YEAR),
            tomorrowCal.get(Calendar.MONTH) + 1,
            tomorrowCal.get(Calendar.DAY_OF_MONTH)
        )

        val todayTimes = PrayerTimeCalculator.calculateForTehran(today)
        val tomorrowTimes = PrayerTimeCalculator.calculateForTehran(tomorrow)

        val pairs = listOf(
            Pair(todayTimes.fajr, tomorrowTimes.fajr),
            Pair(todayTimes.dhuhr, tomorrowTimes.dhuhr),
            Pair(todayTimes.maghrib, tomorrowTimes.maghrib)
        )

        val preMins = prefs.preAdhanMinutes

        for ((todayItem, tomorrowItem) in pairs) {
            if (!prefs.isPrayerEnabled(todayItem.type)) continue

            val targetCal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, todayItem.hour)
                set(Calendar.MINUTE, todayItem.minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            var chosenItem = todayItem

            if (targetCal.timeInMillis <= now.timeInMillis + 10_000L) {
                targetCal.set(Calendar.YEAR, tomorrow.year)
                targetCal.set(Calendar.MONTH, tomorrow.month - 1)
                targetCal.set(Calendar.DAY_OF_MONTH, tomorrow.day)
                targetCal.set(Calendar.HOUR_OF_DAY, tomorrowItem.hour)
                targetCal.set(Calendar.MINUTE, tomorrowItem.minute)
                targetCal.set(Calendar.SECOND, 0)
                targetCal.set(Calendar.MILLISECOND, 0)
                chosenItem = tomorrowItem
            }

            scheduleExactPrayer(context, alarmManager, targetCal.timeInMillis, chosenItem.type, chosenItem.formattedEnglish())

            if (preMins > 0) {
                val preMillis = targetCal.timeInMillis - preMins * 60_000L
                if (preMillis > now.timeInMillis + 10_000L) {
                    schedulePreAdhan(context, alarmManager, preMillis, chosenItem.type, chosenItem.formattedEnglish(), preMins)
                }
            }
        }

        scheduleNextWidgetRefresh(context, alarmManager)
        scheduleDailyFinanceCheck(context, alarmManager, prefs)
        scheduleTodoReminders(context, alarmManager)
    }

    fun scheduleDailyFinanceCheck(context: Context, alarmManager: AlarmManager, prefs: PrefsManager) {
        val now = Calendar.getInstance()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, prefs.financeReminderHour)
            set(Calendar.MINUTE, prefs.financeReminderMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis + 30_000L) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        val intent = Intent(context, InternalAlarmReceiver::class.java).apply {
            action = ACTION_FINANCE_CHECK
        }
        val pi = PendingIntent.getBroadcast(
            context,
            FINANCE_CHECK_REQ_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }

    fun scheduleTodoReminders(context: Context, alarmManager: AlarmManager) {
        val nowMillis = System.currentTimeMillis()
        val tasks = TodoRepository.getAllTasks(context)
        for (task in tasks) {
            val reqCode = 5000 + (task.id.hashCode() and 0x0FFF)
            if (task.isCompleted || task.dueDateKey.isNullOrBlank() || task.reminderTime.isNullOrBlank()) {
                cancelAlarm(context, alarmManager, reqCode, ACTION_TODO_REMINDER)
                continue
            }
            val jDate = PersianCalendarUtils.parseDateKey(task.dueDateKey) ?: continue
            val tParts = task.reminderTime.split(":")
            if (tParts.size != 2) continue
            val hr = tParts[0].toIntOrNull() ?: continue
            val mn = tParts[1].toIntOrNull() ?: continue

            val gDate = PersianCalendarUtils.jalaliToGregorian(jDate.year, jDate.month, jDate.day)
            val cal = Calendar.getInstance().apply {
                set(gDate.year, gDate.month - 1, gDate.day, hr, mn, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (cal.timeInMillis <= nowMillis + 5_000L) continue

            val intent = Intent(context, InternalAlarmReceiver::class.java).apply {
                action = ACTION_TODO_REMINDER
                putExtra(EXTRA_TODO_ID, task.id)
                putExtra(EXTRA_TODO_TITLE, task.title)
            }
            val pi = PendingIntent.getBroadcast(
                context,
                reqCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                } else {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                }
            } catch (_: SecurityException) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
        }
    }

    private fun scheduleExactPrayer(
        context: Context,
        alarmManager: AlarmManager,
        triggerAtMillis: Long,
        type: PrayerType,
        timeFormatted: String
    ) {
        val intent = Intent(context, InternalAlarmReceiver::class.java).apply {
            action = ACTION_PLAY_ADHAN
            putExtra(EXTRA_PRAYER_KEY, type.key)
            putExtra(EXTRA_PRAYER_TIME, timeFormatted)
        }
        val operation = PendingIntent.getBroadcast(
            context,
            type.alarmId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val showIntent = PendingIntent.getActivity(
            context,
            type.alarmId + 50,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, operation)
            } else {
                alarmManager.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAtMillis, showIntent), operation)
            }
        } catch (_: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, operation)
        }
    }

    private fun schedulePreAdhan(
        context: Context,
        alarmManager: AlarmManager,
        triggerAtMillis: Long,
        type: PrayerType,
        timeFormatted: String,
        preMinutes: Int
    ) {
        val intent = Intent(context, InternalAlarmReceiver::class.java).apply {
            action = ACTION_PRE_ADHAN
            putExtra(EXTRA_PRAYER_KEY, type.key)
            putExtra(EXTRA_PRAYER_TIME, timeFormatted)
            putExtra(EXTRA_PRE_MINUTES, preMinutes)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            type.preAlarmId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            }
        } catch (_: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        }
    }

    private fun scheduleNextWidgetRefresh(context: Context, alarmManager: AlarmManager) {
        val now = Calendar.getInstance()
        val today = GregorianDate(now.get(Calendar.YEAR), now.get(Calendar.MONTH) + 1, now.get(Calendar.DAY_OF_MONTH))
        val times = PrayerTimeCalculator.calculateForTehran(today).allOrdered()
        var nextTrigger: Long? = null

        for (item in times) {
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, item.hour)
                set(Calendar.MINUTE, item.minute)
                set(Calendar.SECOND, 5)
                set(Calendar.MILLISECOND, 0)
            }
            if (cal.timeInMillis > now.timeInMillis + 5_000L) {
                nextTrigger = cal.timeInMillis
                break
            }
        }

        val triggerTime = nextTrigger ?: Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 1)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val intent = Intent(context, InternalAlarmReceiver::class.java).apply {
            action = ACTION_REFRESH_WIDGET
        }
        val pi = PendingIntent.getBroadcast(
            context,
            WIDGET_REFRESH_REQ_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pi)
    }

    private fun cancelAlarm(context: Context, alarmManager: AlarmManager, reqCode: Int, action: String) {
        val intent = Intent(context, InternalAlarmReceiver::class.java).apply {
            this.action = action
        }
        val pi = PendingIntent.getBroadcast(
            context,
            reqCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            alarmManager.cancel(pi)
            pi.cancel()
        }
    }
}
