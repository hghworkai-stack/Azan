package ir.azangoo.app.ui

import android.app.TimePickerDialog
import android.graphics.Paint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.azangoo.app.R
import ir.azangoo.app.alarm.AdhanScheduler
import ir.azangoo.app.databinding.FragmentTodoBinding
import ir.azangoo.app.databinding.ItemTodoTaskBinding
import ir.azangoo.app.model.JalaliDate
import ir.azangoo.app.model.TodoRepeatType
import ir.azangoo.app.model.TodoStep
import ir.azangoo.app.model.TodoTask
import ir.azangoo.app.utils.PersianCalendarUtils
import ir.azangoo.app.utils.TodoRepository
import ir.azangoo.app.widget.TodoWidgetProvider
import java.util.UUID

class TodoFragment : Fragment() {

    companion object {
        private const val ARG_LIST_ID = "arg_list_id"
        private const val ARG_QUICK_ADD = "arg_quick_add"

        fun newInstance(listId: String?, quickAdd: Boolean): TodoFragment {
            return TodoFragment().apply {
                arguments = Bundle().apply {
                    if (listId != null) putString(ARG_LIST_ID, listId)
                    putBoolean(ARG_QUICK_ADD, quickAdd)
                }
            }
        }
    }

    private var _binding: FragmentTodoBinding? = null
    private val binding get() = _binding!!

    private var activeFilterId: String = TodoRepository.LIST_MY_DAY
    private var showCompleted: Boolean = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTodoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        arguments?.getString(ARG_LIST_ID)?.let { activeFilterId = it }

        binding.fabAddTask.setOnClickListener { showQuickAddTaskDialog() }
        binding.btnAddList.setOnClickListener { showNewListDialog() }
        binding.btnMyDaySuggestions.setOnClickListener { showMyDaySuggestionsDialog() }
        binding.btnToggleCompleted.setOnClickListener {
            showCompleted = !showCompleted
            renderTasks()
        }

        renderListChips()
        renderTasks()

        if (arguments?.getBoolean(ARG_QUICK_ADD, false) == true) {
            arguments?.putBoolean(ARG_QUICK_ADD, false)
            view.post { showQuickAddTaskDialog() }
        }
    }

    override fun onResume() {
        super.onResume()
        renderListChips()
        renderTasks()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun renderListChips() {
        val ctx = requireContext()
        val group = binding.chipGroupLists
        group.removeAllViews()

        val builtIns = listOf(
            Pair(TodoRepository.LIST_MY_DAY, "روز من"),
            Pair(TodoRepository.LIST_IMPORTANT, "مهم"),
            Pair(TodoRepository.LIST_PLANNED, "برنامه‌ریزی‌شده"),
            Pair(TodoRepository.LIST_ALL, "همه کارها")
        )
        val customs = TodoRepository.getCustomLists(ctx).map { Pair(it.id, it.name) }

        for ((id, title) in builtIns + customs) {
            val chip = Chip(ctx).apply {
                text = title
                isCheckable = true
                isChecked = (id == activeFilterId)
                setOnClickListener {
                    activeFilterId = id
                    renderListChips()
                    renderTasks()
                }
                if (id != TodoRepository.LIST_DEFAULT && !id.startsWith("smart_")) {
                    setOnLongClickListener {
                        MaterialAlertDialogBuilder(ctx)
                            .setTitle("حذف لیست «$title»")
                            .setMessage("این لیست و تمام کارهای داخل آن حذف شوند؟")
                            .setPositiveButton("حذف") { _, _ ->
                                TodoRepository.deleteCustomList(ctx, id)
                                if (activeFilterId == id) activeFilterId = TodoRepository.LIST_MY_DAY
                                refreshEverything()
                            }
                            .setNegativeButton("انصراف", null)
                            .show()
                        true
                    }
                }
            }
            group.addView(chip)
        }
    }

    private fun renderTasks() {
        val ctx = requireContext()
        val allInFilter = TodoRepository.getTasksForFilter(ctx, activeFilterId)
        val openTasks = allInFilter.filter { !it.isCompleted }
        val completedTasks = allInFilter.filter { it.isCompleted }

        val titleLabel = when (activeFilterId) {
            TodoRepository.LIST_MY_DAY -> "روز من (${PersianCalendarUtils.formatJalaliShort(PersianCalendarUtils.todayJalali())})"
            TodoRepository.LIST_IMPORTANT -> "کارهای مهم"
            TodoRepository.LIST_PLANNED -> "برنامه‌ریزی‌شده"
            TodoRepository.LIST_ALL -> "همه کارها"
            else -> TodoRepository.getCustomLists(ctx).firstOrNull { it.id == activeFilterId }?.name ?: "کارها"
        }
        binding.tvTodoHeaderTitle.text = titleLabel

        // Show "پیشنهادهای دیروز" button only on My Day when there are suggestions
        val suggestions = TodoRepository.getSuggestedTasksForMyDay(ctx)
        binding.btnMyDaySuggestions.visibility =
            if (activeFilterId == TodoRepository.LIST_MY_DAY && suggestions.isNotEmpty()) View.VISIBLE else View.GONE

        binding.containerOpenTasks.removeAllViews()
        if (openTasks.isEmpty()) {
            binding.tvTodoEmpty.visibility = View.VISIBLE
        } else {
            binding.tvTodoEmpty.visibility = View.GONE
            for (task in openTasks) {
                binding.containerOpenTasks.addView(buildTaskRow(task))
            }
        }

        if (completedTasks.isEmpty()) {
            binding.btnToggleCompleted.visibility = View.GONE
            binding.containerCompletedTasks.visibility = View.GONE
        } else {
            binding.btnToggleCompleted.visibility = View.VISIBLE
            val arrow = if (showCompleted) "▲" else "▼"
            binding.btnToggleCompleted.text =
                "انجام‌شده‌ها (${PersianCalendarUtils.toPersianDigits(completedTasks.size)}) $arrow"
            binding.containerCompletedTasks.visibility = if (showCompleted) View.VISIBLE else View.GONE
            binding.containerCompletedTasks.removeAllViews()
            if (showCompleted) {
                for (task in completedTasks) {
                    binding.containerCompletedTasks.addView(buildTaskRow(task))
                }
            }
        }
    }

    private fun buildTaskRow(task: TodoTask): View {
        val ctx = requireContext()
        val row = ItemTodoTaskBinding.inflate(LayoutInflater.from(ctx), binding.containerOpenTasks, false)
        val todayKey = PersianCalendarUtils.todayDateKey()

        row.cbTaskDone.isChecked = task.isCompleted
        row.tvTaskTitle.text = task.title
        if (task.isCompleted) {
            row.tvTaskTitle.paintFlags = row.tvTaskTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            row.tvTaskTitle.alpha = 0.55f
        } else {
            row.tvTaskTitle.paintFlags = row.tvTaskTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            row.tvTaskTitle.alpha = 1.0f
        }

        val metaParts = mutableListOf<String>()
        var isOverdue = false
        task.dueDateKey?.let { key ->
            PersianCalendarUtils.parseDateKey(key)?.let { j ->
                if (!task.isCompleted && key < todayKey) isOverdue = true
                val label = when {
                    key == todayKey -> "امروز"
                    else -> PersianCalendarUtils.formatJalaliShort(j)
                }
                metaParts.add(label)
            }
        }
        if (!task.reminderTime.isNullOrBlank()) {
            metaParts.add("⏰ ${PersianCalendarUtils.toPersianDigits(task.reminderTime)}")
        }
        if (task.repeatType != TodoRepeatType.NONE) {
            metaParts.add("↻ ${task.repeatType.persianLabel}")
        }
        if (task.steps.isNotEmpty()) {
            val done = task.steps.count { it.isDone }
            metaParts.add("${PersianCalendarUtils.toPersianDigits(done)}/${PersianCalendarUtils.toPersianDigits(task.steps.size)} مرحله")
        }

        if (metaParts.isEmpty()) {
            row.tvTaskMeta.visibility = View.GONE
        } else {
            row.tvTaskMeta.visibility = View.VISIBLE
            row.tvTaskMeta.text = metaParts.joinToString(" • ")
            row.tvTaskMeta.setTextColor(
                ContextCompat.getColor(ctx, if (isOverdue) R.color.azangoo_holiday else R.color.azangoo_text_secondary)
            )
        }

        row.btnTaskStar.setImageResource(if (task.isImportant) R.drawable.ic_star_filled else R.drawable.ic_star_outline)
        row.btnTaskStar.setOnClickListener {
            TodoRepository.toggleTaskImportant(ctx, task.id)
            refreshEverything()
        }

        row.cbTaskDone.setOnClickListener {
            TodoRepository.toggleTaskCompleted(ctx, task.id)
            refreshEverything()
        }

        row.root.setOnClickListener {
            showTaskDetailsDialog(task)
        }

        return row.root
    }

    private fun showQuickAddTaskDialog() {
        val ctx = requireContext()
        val et = EditText(ctx).apply {
            hint = "عنوان کار را بنویسید..."
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 8)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            addView(et)
        }

        MaterialAlertDialogBuilder(ctx)
            .setTitle("افزودن کار جدید")
            .setView(box)
            .setPositiveButton("افزودن") { _, _ ->
                val title = et.text.toString().trim()
                if (title.isBlank()) return@setPositiveButton
                val todayKey = PersianCalendarUtils.todayDateKey()
                val targetListId = if (activeFilterId.startsWith("smart_")) TodoRepository.LIST_DEFAULT else activeFilterId
                val newTask = TodoTask(
                    id = "task_${UUID.randomUUID().toString().take(8)}",
                    listId = targetListId,
                    title = title,
                    isImportant = (activeFilterId == TodoRepository.LIST_IMPORTANT),
                    myDayDateKey = if (activeFilterId == TodoRepository.LIST_MY_DAY) todayKey else null,
                    dueDateKey = if (activeFilterId == TodoRepository.LIST_PLANNED) todayKey else null
                )
                TodoRepository.upsertTask(ctx, newTask)
                refreshEverything()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun showTaskDetailsDialog(task: TodoTask) {
        val ctx = requireContext()
        var draft = task
        val todayKey = PersianCalendarUtils.todayDateKey()

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 12)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val etTitle = EditText(ctx).apply {
            setText(draft.title)
            hint = "عنوان کار"
        }
        val etNote = EditText(ctx).apply {
            setText(draft.note)
            hint = "یادداشت (اختیاری)"
            minLines = 2
        }
        val cbMyDay = CheckBox(ctx).apply {
            text = "افزودن به «روز من»"
            isChecked = (draft.myDayDateKey == todayKey)
        }

        val tvDue = TextView(ctx).apply {
            textSize = 14f
            setPadding(0, 16, 0, 8)
            setTextColor(ContextCompat.getColor(ctx, R.color.azangoo_primary))
        }
        fun refreshDueText() {
            val dLabel = draft.dueDateKey?.let { k ->
                PersianCalendarUtils.parseDateKey(k)?.let { PersianCalendarUtils.formatJalaliShort(it) }
            } ?: "تعیین نشده"
            val rLabel = draft.reminderTime?.let { " | ساعت ${PersianCalendarUtils.toPersianDigits(it)}" } ?: ""
            tvDue.text = "تاریخ سررسید: $dLabel$rLabel  (برای تغییر لمس کنید)"
        }
        refreshDueText()
        tvDue.setOnClickListener {
            showJalaliDateQuickPicker(draft.dueDateKey) { pickedKey ->
                draft = draft.copy(dueDateKey = pickedKey)
                refreshDueText()
            }
        }

        val tvReminder = TextView(ctx).apply {
            textSize = 14f
            setPadding(0, 8, 0, 8)
            setTextColor(ContextCompat.getColor(ctx, R.color.azangoo_primary))
            text = "تنظیم ساعت یادآور (نوتیفیکیشن)"
        }
        tvReminder.setOnClickListener {
            TimePickerDialog(ctx, { _, hr, mn ->
                val tStr = String.format("%02d:%02d", hr, mn)
                val due = draft.dueDateKey ?: todayKey
                draft = draft.copy(dueDateKey = due, reminderTime = tStr)
                refreshDueText()
            }, 9, 0, true).show()
        }

        val tvRepeat = TextView(ctx).apply {
            textSize = 14f
            setPadding(0, 8, 0, 12)
            setTextColor(ContextCompat.getColor(ctx, R.color.azangoo_primary))
        }
        fun refreshRepeatText() {
            tvRepeat.text = "تکرار: ${draft.repeatType.persianLabel}  (برای تغییر لمس کنید)"
        }
        refreshRepeatText()
        tvRepeat.setOnClickListener {
            val opts = TodoRepeatType.entries.map { it.persianLabel }.toTypedArray()
            MaterialAlertDialogBuilder(ctx)
                .setTitle("تکرار کار")
                .setItems(opts) { _, which ->
                    draft = draft.copy(repeatType = TodoRepeatType.entries[which])
                    refreshRepeatText()
                }
                .show()
        }

        // Steps (sub-tasks) section
        val stepsContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        fun renderSteps() {
            stepsContainer.removeAllViews()
            for (step in draft.steps) {
                val cb = CheckBox(ctx).apply {
                    text = step.title
                    isChecked = step.isDone
                    setOnCheckedChangeListener { _, checked ->
                        draft = draft.copy(
                            steps = draft.steps.map { if (it.id == step.id) it.copy(isDone = checked) else it }
                        )
                    }
                }
                stepsContainer.addView(cb)
            }
        }
        renderSteps()

        val etNewStep = EditText(ctx).apply { hint = "+ افزودن زیرکار (مرحله) جدید..." }
        val tvAddStep = TextView(ctx).apply {
            text = "+ ثبت زیرکار"
            setPadding(0, 6, 0, 12)
            setTextColor(ContextCompat.getColor(ctx, R.color.azangoo_primary))
            setOnClickListener {
                val st = etNewStep.text.toString().trim()
                if (st.isNotEmpty()) {
                    val newStep = TodoStep(id = "st_${UUID.randomUUID().toString().take(6)}", title = st)
                    draft = draft.copy(steps = draft.steps + newStep)
                    etNewStep.setText("")
                    renderSteps()
                }
            }
        }

        root.addView(etTitle)
        root.addView(etNote)
        root.addView(cbMyDay)
        root.addView(tvDue)
        root.addView(tvReminder)
        root.addView(tvRepeat)
        root.addView(stepsContainer)
        root.addView(etNewStep)
        root.addView(tvAddStep)

        val scroll = android.widget.ScrollView(ctx).apply { addView(root) }

        MaterialAlertDialogBuilder(ctx)
            .setTitle("جزئیات کار")
            .setView(scroll)
            .setPositiveButton("ذخیره") { _, _ ->
                val updated = draft.copy(
                    title = etTitle.text.toString().trim().ifBlank { draft.title },
                    note = etNote.text.toString().trim(),
                    myDayDateKey = if (cbMyDay.isChecked) todayKey else null
                )
                TodoRepository.upsertTask(ctx, updated)
                refreshEverything()
            }
            .setNeutralButton("حذف کار") { _, _ ->
                TodoRepository.deleteTask(ctx, task.id)
                refreshEverything()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun showJalaliDateQuickPicker(currentKey: String?, onPicked: (String?) -> Unit) {
        val ctx = requireContext()
        val today = PersianCalendarUtils.todayJalali()
        val tomorrow = PersianCalendarUtils.addDaysJalali(today, 1)
        val nextWeek = PersianCalendarUtils.addDaysJalali(today, 7)

        val options = arrayOf(
            "امروز (${PersianCalendarUtils.formatJalaliShort(today)})",
            "فردا (${PersianCalendarUtils.formatJalaliShort(tomorrow)})",
            "هفته آینده (${PersianCalendarUtils.formatJalaliShort(nextWeek)})",
            "انتخاب تاریخ شمسی دلخواه...",
            "حذف تاریخ"
        )
        MaterialAlertDialogBuilder(ctx)
            .setTitle("تاریخ سررسید")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> onPicked(PersianCalendarUtils.toDateKey(today))
                    1 -> onPicked(PersianCalendarUtils.toDateKey(tomorrow))
                    2 -> onPicked(PersianCalendarUtils.toDateKey(nextWeek))
                    3 -> showManualJalaliInput(currentKey, onPicked)
                    4 -> onPicked(null)
                }
            }
            .show()
    }

    private fun showManualJalaliInput(currentKey: String?, onPicked: (String?) -> Unit) {
        val ctx = requireContext()
        val base = PersianCalendarUtils.parseDateKey(currentKey) ?: PersianCalendarUtils.todayJalali()
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(48, 24, 48, 8)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val etDay = EditText(ctx).apply {
            hint = "روز"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(base.day.toString())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val etMonth = EditText(ctx).apply {
            hint = "ماه"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(base.month.toString())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val etYear = EditText(ctx).apply {
            hint = "سال"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(base.year.toString())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f)
        }
        layout.addView(etDay)
        layout.addView(etMonth)
        layout.addView(etYear)

        MaterialAlertDialogBuilder(ctx)
            .setTitle("تاریخ شمسی (روز / ماه / سال)")
            .setView(layout)
            .setPositiveButton("تأیید") { _, _ ->
                val y = etYear.text.toString().toIntOrNull() ?: base.year
                val m = (etMonth.text.toString().toIntOrNull() ?: base.month).coerceIn(1, 12)
                val maxD = PersianCalendarUtils.daysInJalaliMonth(y, m)
                val d = (etDay.text.toString().toIntOrNull() ?: base.day).coerceIn(1, maxD)
                onPicked(PersianCalendarUtils.toDateKey(JalaliDate(y, m, d)))
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun showNewListDialog() {
        val ctx = requireContext()
        val et = EditText(ctx).apply { hint = "مثلاً: خرید، کاری، شخصی..." }
        val box = LinearLayout(ctx).apply {
            setPadding(48, 24, 48, 8)
            addView(et)
        }
        MaterialAlertDialogBuilder(ctx)
            .setTitle("ساخت لیست جدید")
            .setView(box)
            .setPositiveButton("ایجاد") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isNotEmpty()) {
                    val created = TodoRepository.addCustomList(ctx, name)
                    activeFilterId = created.id
                    refreshEverything()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun showMyDaySuggestionsDialog() {
        val ctx = requireContext()
        val suggestions = TodoRepository.getSuggestedTasksForMyDay(ctx)
        if (suggestions.isEmpty()) return
        val names = suggestions.map { it.title }.toTypedArray()
        val todayKey = PersianCalendarUtils.todayDateKey()
        MaterialAlertDialogBuilder(ctx)
            .setTitle("پیشنهاد کار برای «روز من»")
            .setItems(names) { _, which ->
                val picked = suggestions[which]
                TodoRepository.upsertTask(ctx, picked.copy(myDayDateKey = todayKey))
                refreshEverything()
                Toast.makeText(ctx, "به «روز من» اضافه شد", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("بستن", null)
            .show()
    }

    private fun refreshEverything() {
        val ctx = requireContext()
        AdhanScheduler.scheduleAll(ctx)
        TodoWidgetProvider.updateAllWidgets(ctx)
        renderListChips()
        renderTasks()
    }
}
