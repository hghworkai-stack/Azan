package ir.azangoo.app.utils

import ir.azangoo.app.model.GregorianDate
import ir.azangoo.app.model.HijriDate
import ir.azangoo.app.model.JalaliDate
import java.util.Calendar
import java.util.TimeZone

object PersianCalendarUtils {

    val JALALI_MONTHS = arrayOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    val HIJRI_MONTHS = arrayOf(
        "محرم", "صفر", "ربیع‌الاول", "ربیع‌الثانی", "جمادی‌الاول", "جمادی‌الثانی",
        "رجب", "شعبان", "رمضان", "شوال", "ذی‌قعده", "ذی‌حجه"
    )

    val GREGORIAN_MONTHS = arrayOf(
        "ژانویه", "فوریه", "مارس", "آوریل", "مه", "ژوئن",
        "ژوئیه", "اوت", "سپتامبر", "اکتبر", "نوامبر", "دسامبر"
    )

    fun persianWeekdayName(dayOfWeek: Int): String = when (dayOfWeek) {
        Calendar.SATURDAY -> "شنبه"
        Calendar.SUNDAY -> "یکشنبه"
        Calendar.MONDAY -> "دوشنبه"
        Calendar.TUESDAY -> "سه‌شنبه"
        Calendar.WEDNESDAY -> "چهارشنبه"
        Calendar.THURSDAY -> "پنج‌شنبه"
        Calendar.FRIDAY -> "جمعه"
        else -> ""
    }

    fun persianWeekdayIndex(dayOfWeek: Int): Int = when (dayOfWeek) {
        Calendar.SATURDAY -> 0
        Calendar.SUNDAY -> 1
        Calendar.MONDAY -> 2
        Calendar.TUESDAY -> 3
        Calendar.WEDNESDAY -> 4
        Calendar.THURSDAY -> 5
        Calendar.FRIDAY -> 6
        else -> 0
    }

    fun toPersianDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            if (ch in '0'..'9') {
                sb.append(('۰'.code + (ch - '0')).toChar())
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun toPersianDigits(number: Int): String = toPersianDigits(number.toString())

    fun todayGregorian(): GregorianDate {
        val cal = Calendar.getInstance()
        return GregorianDate(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun todayJalali(): JalaliDate {
        val g = todayGregorian()
        return gregorianToJalali(g.year, g.month, g.day)
    }

    fun gregorianToJalali(gyInput: Int, gm: Int, gd: Int): JalaliDate {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        var gy = gyInput
        var jy: Int
        if (gy > 1600) {
            jy = 979
            gy -= 1600
        } else {
            jy = 0
            gy -= 621
        }
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) - 80 + gd + gdm[gm - 1]
        jy += 33 * (days / 12053)
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + (days / 31)
            jd = 1 + (days % 31)
        } else {
            jm = 7 + ((days - 186) / 30)
            jd = 1 + ((days - 186) % 30)
        }
        return JalaliDate(jy, jm, jd)
    }

    fun jalaliToGregorian(jyInput: Int, jm: Int, jd: Int): GregorianDate {
        var jy = jyInput
        var gy: Int
        if (jy > 979) {
            gy = 1600
            jy -= 979
        } else {
            gy = 621
        }
        var days = (365 * jy) + ((jy / 33) * 8) + (((jy % 33) + 3) / 4) + 78 + jd +
            if (jm < 7) (jm - 1) * 31 else ((jm - 7) * 30) + 186
        gy += 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            days -= 1
            gy += 100 * (days / 36524)
            days %= 36524
            if (days >= 365) days += 1
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        var gd = days + 1
        val isLeap = (gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0)
        val salA = intArrayOf(0, 31, if (isLeap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 1
        for (i in 1..12) {
            if (gd <= salA[i]) {
                gm = i
                break
            }
            gd -= salA[i]
        }
        return GregorianDate(gy, gm, gd)
    }

    fun gregorianToJdn(y: Int, m: Int, d: Int): Int {
        val a = (14 - m) / 12
        val y2 = y + 4800 - a
        val m2 = m + 12 * a - 3
        return d + (153 * m2 + 2) / 5 + 365 * y2 + y2 / 4 - y2 / 100 + y2 / 400 - 32045
    }

    fun gregorianToHijri(y: Int, m: Int, d: Int, offsetDays: Int = 0): HijriDate {
        val jdn = gregorianToJdn(y, m, d) + offsetDays
        var l = jdn - 1948440 + 10632
        val n = (l - 1) / 10631
        l = l - 10631 * n + 354
        val j = ((10985 - l) / 5316) * ((50 * l) / 17719) + (l / 5670) * ((43 * l) / 15238)
        l = l - ((30 - j) / 15) * ((17719 * j) / 50) - (j / 16) * ((15238 * j) / 43) + 29
        val hm = (24 * l) / 709
        val hd = l - (709 * hm) / 24
        val hy = 30 * n + j - 30
        return HijriDate(hy, hm, hd)
    }

    fun daysInJalaliMonth(jy: Int, jm: Int): Int {
        return when {
            jm <= 6 -> 31
            jm <= 11 -> 30
            else -> {
                val g1 = jalaliToGregorian(jy, 12, 1)
                val g2 = jalaliToGregorian(jy + 1, 1, 1)
                gregorianToJdn(g2.year, g2.month, g2.day) - gregorianToJdn(g1.year, g1.month, g1.day)
            }
        }
    }

    fun dayOfWeekForJalali(jy: Int, jm: Int, jd: Int): Int {
        val g = jalaliToGregorian(jy, jm, jd)
        val cal = Calendar.getInstance(TimeZone.getDefault())
        cal.set(g.year, g.month - 1, g.day, 12, 0, 0)
        return cal.get(Calendar.DAY_OF_WEEK)
    }

    fun formatJalaliFull(j: JalaliDate): String {
        val dow = dayOfWeekForJalali(j.year, j.month, j.day)
        val wName = persianWeekdayName(dow)
        val mName = JALALI_MONTHS[(j.month - 1).coerceIn(0, 11)]
        return "$wName ${toPersianDigits(j.day)} $mName ${toPersianDigits(j.year)}"
    }

    fun formatHijriFull(h: HijriDate): String {
        val mName = HIJRI_MONTHS[(h.month - 1).coerceIn(0, 11)]
        return "${toPersianDigits(h.day)} $mName ${toPersianDigits(h.year)}"
    }

    fun formatGregorianFull(g: GregorianDate): String {
        val mName = GREGORIAN_MONTHS[(g.month - 1).coerceIn(0, 11)]
        return "${toPersianDigits(g.day)} $mName ${toPersianDigits(g.year)}"
    }

    fun toDateKey(j: JalaliDate): String = String.format("%04d-%02d-%02d", j.year, j.month, j.day)

    fun todayDateKey(): String = toDateKey(todayJalali())

    fun parseDateKey(key: String?): JalaliDate? {
        if (key.isNullOrBlank()) return null
        val parts = key.split("-")
        if (parts.size != 3) return null
        val y = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        val d = parts[2].toIntOrNull() ?: return null
        return JalaliDate(y, m.coerceIn(1, 12), d.coerceIn(1, 31))
    }

    fun addMonthsJalali(start: JalaliDate, monthsToAdd: Int): JalaliDate {
        val totalMonths = (start.year * 12) + (start.month - 1) + monthsToAdd
        val newYear = totalMonths / 12
        val newMonth = (totalMonths % 12) + 1
        val maxDay = daysInJalaliMonth(newYear, newMonth)
        val newDay = start.day.coerceAtMost(maxDay)
        return JalaliDate(newYear, newMonth, newDay)
    }

    fun addDaysJalali(start: JalaliDate, daysToAdd: Int): JalaliDate {
        val g = jalaliToGregorian(start.year, start.month, start.day)
        val cal = Calendar.getInstance()
        cal.set(g.year, g.month - 1, g.day, 12, 0, 0)
        cal.add(Calendar.DAY_OF_YEAR, daysToAdd)
        return gregorianToJalali(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun daysBetweenJalali(from: JalaliDate, to: JalaliDate): Int {
        val g1 = jalaliToGregorian(from.year, from.month, from.day)
        val g2 = jalaliToGregorian(to.year, to.month, to.day)
        return gregorianToJdn(g2.year, g2.month, g2.day) - gregorianToJdn(g1.year, g1.month, g1.day)
    }

    fun formatJalaliShort(j: JalaliDate): String {
        val mName = JALALI_MONTHS[(j.month - 1).coerceIn(0, 11)]
        return "${toPersianDigits(j.day)} $mName ${toPersianDigits(j.year)}"
    }

    fun formatToman(amount: Long): String {
        val str = String.format("%,d", amount).replace(',', '٬')
        return "${toPersianDigits(str)} تومان"
    }
}
